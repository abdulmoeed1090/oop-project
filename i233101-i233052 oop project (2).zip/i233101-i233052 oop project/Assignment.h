#ifndef ASSIGNMENT_H
#define ASSIGNMENT_H

#include <iostream>
#include <fstream>
using namespace std;

// class assignment
class Assignment
{
private:
    // data members
    int assignmentID;        // Assignment ID
    string description;      // Assignment description
    int maxScore;            // Maximum score of the assignment
    int totalMarks;          // Total marks of the assignment
    string dueDate;          // Due date of the assignment
    string submission;       // Submission status

public:
    //------------------ operator overloading ------------------
    
    // Equality operator to compare two Assignment objects
    bool operator==(const Assignment &obj) const
    {
        return (assignmentID == obj.assignmentID &&
                description == obj.description &&
                dueDate == obj.dueDate &&
                submission == obj.submission && maxScore == obj.maxScore);
    }

    // Assignment operator to copy data from one Assignment object to another
    Assignment &operator=(const Assignment &obj)
    {
        assignmentID = obj.assignmentID;
        description = obj.description;
        submission = obj.submission;
        dueDate = obj.dueDate;
        maxScore = obj.maxScore;
        return *this;
    }

    // Overloading >> to input data for Assignment object
    friend istream &operator>>(istream &in, Assignment &obj)
    {
        cout << "Enter Assignment ID: ";
        in >> obj.assignmentID;
        cout << "Enter Assignment description: ";
        in.ignore();
        getline(in, obj.description);
        cout << "Enter Assignment due date: ";
        getline(in, obj.dueDate);

        cout << "Enter the total marks of the assignment: ";
        cin >> obj.totalMarks;

        return in;
    }

    // Overloading << to output data of Assignment object
    friend ostream &operator<<(ostream &out, const Assignment &obj)
    {
        out << "Assignmnet ID: " << obj.assignmentID << endl;
        out << "Assignment description: " << obj.description << endl;
        out << "Assignment due date: " << obj.dueDate << endl;
        out << "Assignment max score: " << obj.maxScore << endl;
        out << "Assignment submission: " << obj.submission << endl;
        return out;
    }

    // Array-style operator to access data by index
    string operator[](int index) const
    {
        switch (index)
        {
        case 0:
            return to_string(assignmentID);
        case 1:
            return description;
        case 2:
            return dueDate;
        case 3:
            return to_string(maxScore);
        case 4:
            return submission;
        default:
            cout << "Invalid index!!!\n";
            return "";
        }
    }

    // () operator overloaded to access data by member name
    string operator()(const string &dataMember) const
    {
        if (dataMember == "assignmentID")
        {
            return to_string(assignmentID);
        }
        else if (dataMember == "description")
        {
            return description;
        }
        else if (dataMember == "dueDate")
        {
            return dueDate;
        }
        else if (dataMember == "maxScore")
        {
            return to_string(maxScore);
        }

        else if (dataMember == "submission")
        {
            return submission;
        }
        else
            return "Invalid choice !!";
    }

    // Default constructor
    Assignment()
    {
        assignmentID = 0;
        description = "";
        dueDate = "";
        submission = "Not Submitted";
        description = "";
        totalMarks = 0;
    }

    // Parameterized constructor 
    Assignment(int assignmentID, int maxScore, string description, string dueDate, string submission, int totalMarks)
    {
        this->assignmentID = assignmentID;
        this->maxScore = maxScore;
        this->description = description;
        this->dueDate = dueDate;
        this->submission = submission;
        this->totalMarks = totalMarks;
    };

    // Function to display assignment info
    void displayAssignmentInfo()
    {
        cout << "Assignment ID : " << assignmentID << endl;
        cout << "Assignment description : " << description << endl;
        cout << "Assignment submission : " << submission << endl;
        cout << "Assignment deadline : " << dueDate << endl;
        // cout << "Assignment max score : " << maxScore << endl;
    }

    // Getter for Assignment ID
    int getAssignmentID() const
    {
        return assignmentID;
    }

    // Getter for Due Date
    string getDueDate() const
    {
        return dueDate;
    }

    // Setter for Due Date
    void setDueDate(string dueDate)
    {
        this->dueDate = dueDate;
    }

    // Setter for Submission status
    void setSubmission(string submission)
    {
        this->submission = submission;
    }

    // Getter for Submission status
    string getSubmission() const
    {
        return submission;
    }

    // Setter for Description
    void setDescription(string description)
    {
        this->description = description;
    }

    // Getter for Description
    string getDescription()
    {
        return description;
    }

    // Setter for Max Score
    void setMaxScore(int score)
    {
        maxScore = totalMarks - 10;
    }

    // Getter for Max Score
    int getMaxScore()
    {
        return maxScore;
    }

    // Getter for Total Marks
    int getTotalMarks()
    {
        return totalMarks;
    }
    // Method to write assignment data to a binary file
    void writeToBinaryFile(ofstream &outFile) const
    {
        // Write assignmentID
        outFile.write(reinterpret_cast<const char*>(&assignmentID), sizeof(assignmentID));

        // Write description
        size_t descSize = description.size();
        outFile.write(reinterpret_cast<const char*>(&descSize), sizeof(descSize));
        outFile.write(description.c_str(), descSize);

        // Write maxScore
        outFile.write(reinterpret_cast<const char*>(&maxScore), sizeof(maxScore));

        // Write totalMarks
        outFile.write(reinterpret_cast<const char*>(&totalMarks), sizeof(totalMarks));

        // Write dueDate
        size_t dateSize = dueDate.size();
        outFile.write(reinterpret_cast<const char*>(&dateSize), sizeof(dateSize));
        outFile.write(dueDate.c_str(), dateSize);

        // Write submission
        size_t subSize = submission.size();
        outFile.write(reinterpret_cast<const char*>(&subSize), sizeof(subSize));
        outFile.write(submission.c_str(), subSize);
    }

    // Method to read assignment data from a binary file
    void readFromBinaryFile(ifstream &inFile)
    {
        // Read assignmentID
        inFile.read(reinterpret_cast<char*>(&assignmentID), sizeof(assignmentID));

        // Read description
        size_t descSize;
        inFile.read(reinterpret_cast<char*>(&descSize), sizeof(descSize));
        description.resize(descSize);
        inFile.read(&description[0], descSize);

        // Read maxScore
        inFile.read(reinterpret_cast<char*>(&maxScore), sizeof(maxScore));

        // Read totalMarks
        inFile.read(reinterpret_cast<char*>(&totalMarks), sizeof(totalMarks));

        // Read dueDate
        size_t dateSize;
        inFile.read(reinterpret_cast<char*>(&dateSize), sizeof(dateSize));
        dueDate.resize(dateSize);
        inFile.read(&dueDate[0], dateSize);

        // Read submission
        size_t subSize;
        inFile.read(reinterpret_cast<char*>(&subSize), sizeof(subSize));
        submission.resize(subSize);
        inFile.read(&submission[0], subSize);
    }
};

#endif
