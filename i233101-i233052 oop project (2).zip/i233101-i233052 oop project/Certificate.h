#ifndef CERTIFICATE_H
#define CERTIFICATE_H

#include <iostream>
#include <fstream>
using namespace std;

// Certificate class
class Certificate
{
private:
    int certificateID;
    string issueDate;
    string courseTitle;
    string recipient;

public:
    //------------------ operator overloading ------------------

    // Equality operator to compare two Certificate objects
    bool operator==(const Certificate &obj) const
    {
        return (certificateID == obj.certificateID &&
                issueDate == obj.issueDate &&
                courseTitle == obj.courseTitle &&
                recipient == obj.recipient);
    }

    // Assignment operator to assign one Certificate object to another
    Certificate &operator=(const Certificate &obj)
    {
        certificateID = obj.certificateID;
        issueDate = obj.issueDate;
        courseTitle = obj.courseTitle;
        recipient = obj.recipient;
        return *this;
    }

    // Overloading >> to input data for the Certificate object
    friend istream &operator>>(istream &in, Certificate &obj)
    {
        cout << "Enter Certificate ID: ";
        in >> obj.certificateID;
        cout << "Enter Issue Date: ";
        in.ignore();
        getline(in, obj.issueDate);
        cout << "Enter Course Title: ";
        getline(in, obj.courseTitle);
        cout << "Enter Recipient: ";
        getline(in, obj.recipient);
        return in;
    }

    // Overloading << to output data for the Certificate object
    friend ostream &operator<<(ostream &out, const Certificate &obj)
    {
        out << "Certificate ID: " << obj.certificateID << endl;
        out << "Issue Date: " << obj.issueDate << endl;
        out << "Course Title: " << obj.courseTitle << endl;
        out << "Recipient: " << obj.recipient << endl;
        return out;
    }

    // ArrayStyle operator to access data by index
    string operator[](int index) const
    {
        switch (index)
        {
        case 0:
            return to_string(certificateID);
        case 1:
            return issueDate;
        case 2:
            return courseTitle;
        case 3:
            return recipient;
        default:
            cout << "Invalid index!!!\n";
            return "";
        }
    }

    // FunctionStyle operator to access data by member name
    string operator()(const string &dataMember) const
    {
        if (dataMember == "certificateID")
        {
            return to_string(certificateID);
        }
        else if (dataMember == "issueDate")
        {
            return issueDate;
        }
        else if (dataMember == "courseTitle")
        {
            return courseTitle;
        }
        else if (dataMember == "recipient")
        {
            return recipient;
        }
        else
        {
            return "Invalid data member!";
        }
    }

    // Default constructor
    Certificate() : certificateID(0), issueDate(""), courseTitle(""), recipient("") {}

    // Parameterized constructor
    Certificate(int id, string date, string title, string recipient)
    {
        this->certificateID = id;
        this->issueDate = date;
        this->courseTitle = title;
        this->recipient = recipient;
    }

    // Function to display certificate details
    void displayCertificateInfo() const
    {
        cout << "Certificate ID: " << certificateID << endl;
        cout << "Issue Date: " << issueDate << endl;
        cout << "Course Title: " << courseTitle << endl;
        cout << "Recipient: " << recipient << endl;
    }

    // Getter function for certificate ID
    int getCertificateID() const
    {
        return certificateID;
    }

    // Setter function for certificate ID
    void setCID(int s)
    {
        certificateID = s;
    }

    // Setter function for issue date
    void setDate(string d)
    {
        issueDate = d;
    }

    // Setter function for course title
    void setTitle(string t)
    {
        courseTitle = t;
    }

    // Setter function for recipient name
    void setRecepient(string r)
    {
        recipient = r;
    }
    bool writeToBinaryFile(const string &filename) const
    {
        ofstream outFile(filename, ios::binary);
        if (!outFile)
        {
            cerr << "Error opening file for writing: " << filename << endl;
            return false;
        }

        // Write certificateID
        outFile.write(reinterpret_cast<const char *>(&certificateID), sizeof(certificateID));

        // Write issueDate
        size_t dateSize = issueDate.size();
        outFile.write(reinterpret_cast<const char *>(&dateSize), sizeof(dateSize));
        outFile.write(issueDate.c_str(), dateSize);

        // Write courseTitle
        size_t titleSize = courseTitle.size();
        outFile.write(reinterpret_cast<const char *>(&titleSize), sizeof(titleSize));
        outFile.write(courseTitle.c_str(), titleSize);

        // Write recipient
        size_t recipientSize = recipient.size();
        outFile.write(reinterpret_cast<const char *>(&recipientSize), sizeof(recipientSize));
        outFile.write(recipient.c_str(), recipientSize);

        outFile.close();
        return true;
    }

    // Method to read certificate data from a binary file
    bool readFromBinaryFile(const string &filename)
    {
        ifstream inFile(filename, ios::binary);
        if (!inFile)
        {
            cerr << "Error opening file for reading: " << filename << endl;
            return false;
        }

        // Read certificateID
        inFile.read(reinterpret_cast<char *>(&certificateID), sizeof(certificateID));

        // Read issueDate
        size_t dateSize;
        inFile.read(reinterpret_cast<char *>(&dateSize), sizeof(dateSize));
        issueDate.resize(dateSize);
        inFile.read(&issueDate[0], dateSize);

        // Read courseTitle
        size_t titleSize;
        inFile.read(reinterpret_cast<char *>(&titleSize), sizeof(titleSize));
        courseTitle.resize(titleSize);
        inFile.read(&courseTitle[0], titleSize);

        // Read recipient
        size_t recipientSize;
        inFile.read(reinterpret_cast<char *>(&recipientSize), sizeof(recipientSize));
        recipient.resize(recipientSize);
        inFile.read(&recipient[0], recipientSize);

        inFile.close();
        return true;
    }

    // Destructor
    ~Certificate() {}
   
};

#endif
