#ifndef COURSE_H
#define COURSE_H

#include <iostream>
#include "Module.h"
#include "Certificate.h"
#include "Constants.h"
#include <fstream>
using namespace std;

// class course
class Course
{
private:
    // data members
    string courseName = "";
    int courseCode = 00;
    string courseTitle = "";
    Module modules[Constants::MAX_MODULES]; // Array to store modules
    int moduleCount = 00;                   // Counter to keep track of the number of modules

public:
    //------------------ operator overloading ------------------
    // comparison operator
    bool operator==(const Course &obj) const
    {
        return (courseName == obj.courseName &&
                courseTitle == obj.courseTitle &&
                courseCode == obj.courseCode);
    }
    // assignment operator
    Course &operator=(const Course &obj)
    {
        if (this != &obj)
        {
            courseCode = obj.courseCode;
            courseName = obj.courseName;
            courseTitle = obj.courseTitle;
        }
        return *this;
    }

    // instream operator
    friend istream &operator>>(istream &in, Course &obj)
    {
        cout << "Enter Course Code: ";
        in >> obj.courseCode;
        cout << "Enter Course Name: ";
        in.ignore();
        getline(in, obj.courseName);
        cout << "Enter Course Title: ";
        getline(in, obj.courseTitle);

        return in;
    }
    // stream exercision operators
    friend ostream &operator<<(ostream &out, const Course &obj)
    {
        out << "Course Code: " << obj.courseCode << endl;
        out << "Course Name: " << obj.courseName << endl;
        out << "Course Title: " << obj.courseTitle << endl;
        return out;
    }
    // Array subscript operator
    string operator[](int index) const
    {
        switch (index)
        {
        case 0:
            return to_string(courseCode);
        case 1:
            return courseName;
        case 2:
            return courseTitle;
        default:
            cout << "Invalid index!!!\n";
            return "";
        }
    }
    // round bracket operator
    string operator()(const string &dataMember) const
    {
        if (dataMember == "courseCode")
        {
            return to_string(courseCode);
        }
        else if (dataMember == "courseName")
        {
            return courseName;
        }
        else if (dataMember == "courseTitle")
        {
            return courseTitle;
        }
        else
        {
            return "Invalid data member!";
        }
    }
    // constructors
    // default constructor
    Course()
    {
        courseName = "";
        courseCode = 0;
        courseTitle = "";
        int moduleCount = 0;
    }
    // Perametrized constructor
    Course(string courseName, int courseCode, string courseTitle)
    {
        this->courseName = courseName;
        this->courseCode = courseCode;
        this->courseTitle = courseTitle;
    }
    ~Course()
    {
        // delete[] completedCourses;
        // delete[] certificates;
    }

    // functions
    // display course information function
    void displayCourseInfo()
    {
        cout << "Course name : " << this->courseName << endl;
        cout << "Course Title : " << this->courseTitle << endl;
        cout << "Course Code : " << this->courseCode << endl;
    }

    // Methods to manage modules
    bool addModule(const Module &module)
    {
        if (moduleCount < Constants::MAX_MODULES)
        {
            modules[moduleCount] = module;
            moduleCount++;
            return true;
        }
        else
        {
            cout << "Maximum number of modules reached for course " << courseName << endl;
            return false;
        }
    }

    void displayModules() const
    {
        cout << "Modules for course " << courseName << ":" << endl;
        for (int i = 0; i < moduleCount; i++)
        {
            modules[i].displayModuleInfo();
        }
    }

    // Method to generate a certificate
    Certificate generateCertificate(int certificateID, string issueDate) const
    {
        Certificate c;
        c.setCID(certificateID);
        c.setDate(issueDate);
        c.setTitle("Functional programming..\n");
        c.setRecepient("AbdulMoeed\n");
        return c;
    }
    // getters and setters
    void setCourseName(string courseName)
    {
        this->courseName = courseName;
    }
    void setCourseTitle(string courseTitle)
    {
        this->courseTitle = courseTitle;
    }
    void setCourseCode(int courseCode)
    {
        this->courseCode = courseCode;
    }

    string getCourseName() const
    {
        return courseName;
    }
    string getCourseTitle() const
    {
        return courseTitle;
    }
    int getCourseCode() const
    {
        return courseCode;
    }
    //---------------------file handling------------------------
    void saveToFile(const string &filename) const
    {
        ofstream outFile;
        outFile.open(filename, ios::binary | ios::out);
        if (!outFile.is_open())
        {
            cerr << "Error!! Can't open the file " << filename << " for writing...\n";
            return;
        }

        // Write courseCode
        int tempCourseCode = courseCode;
        outFile.write((char *)&tempCourseCode, sizeof(tempCourseCode));

        // Write courseName
        size_t nameSize = courseName.size();
        outFile.write((char *)&nameSize, sizeof(nameSize));
        outFile.write(courseName.c_str(), nameSize);

        // Write courseTitle
        size_t titleSize = courseTitle.size();
        outFile.write((char *)&titleSize, sizeof(titleSize));
        outFile.write(courseTitle.c_str(), titleSize);

        // Write moduleCount
        int tempModuleCount = moduleCount;
        outFile.write((char *)&tempModuleCount, sizeof(tempModuleCount));

        // Write modules
        // for (int i = 0; i < moduleCount; i++)
        // {
        //     modules[i].saveToBinary(outFile); // Assuming Module has a saveToBinary method
        // }

        outFile.close();
        cout << "Course information saved to " << filename << " in binary format.\n";
    }

    void displayFromFile(const string &filename)
    {
        ifstream inFile;
        inFile.open(filename, ios::binary | ios::in);
        if (!inFile.is_open())
        {
            cerr << "Error!! Can't open the file " << filename << " for reading...\n";
            return;
        }

        // Read courseCode
        int tempCourseCode;
        inFile.read((char *)&tempCourseCode, sizeof(tempCourseCode));

        // Read courseName
        size_t nameSize;
        inFile.read((char *)&nameSize, sizeof(nameSize));
        string tempCourseName(nameSize, '\0');
        inFile.read(&tempCourseName[0], nameSize);

        // Read courseTitle
        size_t titleSize;
        inFile.read((char *)&titleSize, sizeof(titleSize));
        string tempCourseTitle(titleSize, '\0');
        inFile.read(&tempCourseTitle[0], titleSize);

        // Read moduleCount
        int tempModuleCount;
        inFile.read((char *)&tempModuleCount, sizeof(tempModuleCount));

        // Display the read data
        cout << "Course Code: " << tempCourseCode << endl;
        cout << "Course Name: " << tempCourseName << endl;
        cout << "Course Title: " << tempCourseTitle << endl;
        cout << "Number of Modules: " << tempModuleCount << endl;

        // If there are modules, you can add code here to read and display them
        // for (int i = 0; i < tempModuleCount; i++) {
        //     // Assuming Module has a method to load from binary
        //     Module module;
        //     module.loadFromBinary(inFile);
        //     module.display(); // Assuming Module has a display method
        // }

        inFile.close();
        cout << "Course information displayed from " << filename << ".\n";
    }
    void writeToBinaryFile(ofstream &outFile) const
    {
        // Write courseCode
        outFile.write(reinterpret_cast<const char*>(&courseCode), sizeof(courseCode));

        // Write courseName
        size_t nameSize = courseName.size();
        outFile.write(reinterpret_cast<const char*>(&nameSize), sizeof(nameSize));
        outFile.write(courseName.c_str(), nameSize);

        // Write courseTitle
        size_t titleSize = courseTitle.size();
        outFile.write(reinterpret_cast<const char*>(&titleSize), sizeof(titleSize));
        outFile.write(courseTitle.c_str(), titleSize);

        // Write moduleCount
        outFile.write(reinterpret_cast<const char*>(&moduleCount), sizeof(moduleCount));

        // Write modules
        for (int i = 0; i < moduleCount; i++)
        {
            modules[i].writeToBinaryFile(outFile);
        }
    }

    void readFromBinaryFile(ifstream &inFile)
    {
        // Read courseCode
        inFile.read(reinterpret_cast<char*>(&courseCode), sizeof(courseCode));

        // Read courseName
        size_t nameSize;
        inFile.read(reinterpret_cast<char*>(&nameSize), sizeof(nameSize));
        courseName.resize(nameSize);
        inFile.read(&courseName[0], nameSize);

        // Read courseTitle
        size_t titleSize;
        inFile.read(reinterpret_cast<char*>(&titleSize), sizeof(titleSize));
        courseTitle.resize(titleSize);
        inFile.read(&courseTitle[0], titleSize);

        // Read moduleCount
        inFile.read(reinterpret_cast<char*>(&moduleCount), sizeof(moduleCount));

        // Read modules
        for (int i = 0; i < moduleCount; i++)
        {
            modules[i].readFromBinaryFile(inFile);
        }
    }
};

#endif