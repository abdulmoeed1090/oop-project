
#ifndef GROUP_H
#define GROUP_H

#include <iostream>
#include "Constants.h"
#include "Task.h"
#include "Message.h"

using namespace std;
// Group class
class Group
{
    static int groupCount;
    static int groupIDs[Constants::MAX_GROUPS];
    static string groupNames[Constants::MAX_GROUPS];
    static int memberCounts[Constants::MAX_GROUPS];
    static string members[Constants::MAX_GROUPS][Constants::MAX_MEMBERS];
    static Task* tasks[Constants::MAX_GROUPS][Constants::MAX_MEMBERS];       // Array to store tasks
    static int taskCounts[Constants::MAX_GROUPS];                            // Counter to keep track of the number of tasks
    static Message* messages[Constants::MAX_GROUPS][Constants::MAX_MEMBERS]; // Array to store messages
    static int messageCounts[Constants::MAX_GROUPS];                         // Counter to keep track of the number of messages

public:
    // -----------------Operator overloading-------------------
    bool operator==(const Group& obj) const
    {
        return (groupCount == obj.groupCount &&
            groupIDs == obj.groupIDs &&
            groupNames == obj.groupNames &&
            memberCounts == obj.memberCounts &&
            members == obj.members &&
            tasks == obj.tasks &&
            taskCounts == obj.taskCounts &&
            messages == obj.messages &&
            messageCounts == obj.messageCounts);
    }
    Group& operator=(const Group& obj)
    {
        groupCount = obj.groupCount;
        for (int i = 0; i < Constants::MAX_GROUPS; ++i)
        {
            groupIDs[i] = obj.groupIDs[i];
            groupNames[i] = obj.groupNames[i];
            memberCounts[i] = obj.memberCounts[i];
            for (int j = 0; j < Constants::MAX_MEMBERS; ++j)
            {
                members[i][j] = obj.members[i][j];
                tasks[i][j] = obj.tasks[i][j];
                messages[i][j] = obj.messages[i][j];
            }
            taskCounts[i] = obj.taskCounts[i];
            messageCounts[i] = obj.messageCounts[i];
        }
        return *this;
    }
    friend istream& operator>>(istream& in, Group& obj)
    {
        cout << "Enter Group Count: ";
        in >> obj.groupCount;
        for (int i = 0; i < obj.groupCount; ++i)
        {
            cout << "Enter Group ID for group " << (i + 1) << ": ";
            in >> obj.groupIDs[i];
            cout << "Enter Group Name for group " << (i + 1) << ": ";
            in.ignore();
            getline(in, obj.groupNames[i]);
            cout << "Enter Member Count for group " << (i + 1) << ": ";
            in >> obj.memberCounts[i];
            for (int j = 0; j < obj.memberCounts[i]; ++j)
            {
                cout << "Enter Member Name " << (j + 1) << " for group " << (i + 1) << ": ";
                in.ignore();
                getline(in, obj.members[i][j]);
            }
            cout << "Enter Task Count for group " << (i + 1) << ": ";
            in >> obj.taskCounts[i];
            for (int j = 0; j < obj.taskCounts[i]; ++j)
            {
                cout << "Enter Task " << (j + 1) << " for group " << (i + 1) << ": ";
                in >> *(obj.tasks[i][j]);
            }
            cout << "Enter Message Count for group " << (i + 1) << ": ";
            in >> obj.messageCounts[i];
            for (int j = 0; j < obj.messageCounts[i]; ++j)
            {
                cout << "Enter Message " << (j + 1) << " for group " << (i + 1) << ": ";
                in >> *(obj.messages[i][j]);
            }
        }
        return in;
    }
    friend ostream& operator<<(ostream& out, const Group& obj)
    {
        out << "Group Count: " << obj.groupCount << endl;
        for (int i = 0; i < obj.groupCount; ++i)
        {
            out << "Group ID: " << obj.groupIDs[i] << endl;
            out << "Group Name: " << obj.groupNames[i] << endl;
            out << "Member Count: " << obj.memberCounts[i] << endl;
            for (int j = 0; j < obj.memberCounts[i]; ++j)
            {
                out << "Member Name " << (j + 1) << ": " << obj.members[i][j] << endl;
            }
            out << "Task Count: " << obj.taskCounts[i] << endl;
            for (int j = 0; j < obj.taskCounts[i]; ++j)
            {
                out << "Task " << (j + 1) << ": " << *(obj.tasks[i][j]) << endl;
            }
            out << "Message Count: " << obj.messageCounts[i] << endl;
            for (int j = 0; j < obj.messageCounts[i]; ++j)
            {
                out << "Message " << (j + 1) << ": " << *(obj.messages[i][j]) << endl;
            }
        }
        return out;
    }
    string operator[](int index) const
    {
        switch (index)
        {
        case 0:
            return to_string(groupCount);
        case 1:
            return to_string(groupIDs[0]);
        case 2:
            return groupNames[0];
        case 3:
            return to_string(memberCounts[0]);
        case 4:
            return members[0][0];
        case 5:
            return to_string(taskCounts[0]);
        case 6:
            return to_string(messageCounts[0]);
        default:
            cout << "Invalid index!!!\n";
            return "";
        }
    }
    string operator()(const string& dataMember) const
    {
        if (dataMember == "groupCount")
        {
            return to_string(groupCount);
        }
        else if (dataMember == "groupIDs")
        {
            return to_string(groupIDs[0]);
        }
        else if (dataMember == "groupNames")
        {
            return groupNames[0];
        }
        else if (dataMember == "memberCounts")
        {
            return to_string(memberCounts[0]);
        }
        else if (dataMember == "members")
        {
            return members[0][0];
        }
        else if (dataMember == "taskCounts")
        {
            return to_string(taskCounts[0]);
        }
        else if (dataMember == "messageCounts")
        {
            return to_string(messageCounts[0]);
        }
        else
        {
            return "Invalid data member!";
        }
    }
    // functions
    static void createGroup(int groupID, const std::string& groupName)
    {
        if (groupCount < Constants::MAX_GROUPS)
        {
            groupIDs[groupCount] = groupID;
            groupNames[groupCount] = groupName;
            memberCounts[groupCount] = 0;
            groupCount++;
            cout << "Group created successfully: " << groupName << endl;
        }
        else
        {
            cout << "Maximum number of groups reached. Cannot create more groups." << endl;
        }
    }

    static void addMemberToGroup(int groupID, const string& memberName)
    {
        int groupIndex = findGroupIndex(groupID);
        if (groupIndex != -1 && memberCounts[groupIndex] < Constants::MAX_MEMBERS)
        {
            members[groupIndex][memberCounts[groupIndex]] = memberName;
            memberCounts[groupIndex]++;
            cout << "Member added to group: " << memberName << endl;
        }
        else
        {
            cout << "Cannot add member to group." << endl;
        }
    }

    static void removeMemberFromGroup(int groupID, const string& memberName)
    {
        int groupIndex = findGroupIndex(groupID);
        if (groupIndex != -1)
        {
            for (int i = 0; i < memberCounts[groupIndex]; ++i)
            {
                if (members[groupIndex][i] == memberName)
                {
                    // Shift members to the left to remove the specified member
                    for (int j = i; j < memberCounts[groupIndex] - 1; ++j)
                    {
                        members[groupIndex][j] = members[groupIndex][j + 1];
                    }
                    memberCounts[groupIndex]--;
                    cout << "Member removed from group: " << memberName << endl;
                    return;
                }
            }
            cout << "Member not found in group." << endl;
        }
        else
        {
            cout << "Group not found." << endl;
        }
    }

    static void displayGroups()
    {
        cout << "Groups:" << endl;
        for (int i = 0; i < groupCount; ++i)
        {
            cout << "Group ID: " << groupIDs[i] << ", Group Name: " << groupNames[i] << endl;
            cout << "Members:" << endl;
            for (int j = 0; j < memberCounts[i]; ++j)
            {
                cout << " - " << members[i][j] << endl;
            }
        }
    }

    static void manageStudyGroups()
    {
        int choice;
        do
        {
            cout << "Study Group Management Menu:" << endl;
            cout << "1. Create Group" << endl;
            cout << "2. Add Member to Group" << endl;
            cout << "3. Remove Member from Group" << endl;
            cout << "4. Display Groups" << endl;
            cout << "5. Handle Peer Discussions" << endl;
            cout << "6. Facilitate Student Collaboration" << endl;
            cout << "7. Exit" << endl;
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice)
            {
            case 1:
            {
                int groupID;
                string groupName;
                cout << "Enter Group ID: ";
                cin >> groupID;
                cout << "Enter Group Name: ";
                cin.ignore(); // Ignore the newline character left in the buffer
                getline(cin, groupName);
                createGroup(groupID, groupName);
                break;
            }
            case 2:
            {
                int groupID;
                string memberName;
                cout << "Enter Group ID: ";
                cin >> groupID;
                cout << "Enter Member Name: ";
                cin.ignore(); // Ignore the newline character left in the buffer
                getline(cin, memberName);
                addMemberToGroup(groupID, memberName);
                break;
            }
            case 3:
            {
                int groupID;
                string memberName;
                cout << "Enter Group ID: ";
                cin >> groupID;
                cout << "Enter Member Name: ";
                cin.ignore(); // Ignore the newline character left in the buffer
                getline(cin, memberName);
                removeMemberFromGroup(groupID, memberName);
                break;
            }
            case 4:
                displayGroups();
                break;
            case 5:
                handlePeerDiscussions();
                break;
            case 6:
                facilitateStudentCollaboration();
                break;
            case 7:
                cout << "Exiting Study Group Management." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
            }
        } while (choice != 7);
    }

    static void handlePeerDiscussions()
    {
        int groupID;
        cout << "Enter Group ID for peer discussions: ";
        cin >> groupID;

        int groupIndex = findGroupIndex(groupID);
        if (groupIndex != -1)
        {
            cout << "Peer Discussion for Group: " << groupNames[groupIndex] << endl;
            cout << "Members:" << endl;
            for (int i = 0; i < memberCounts[groupIndex]; ++i)
            {
                cout << " - " << members[groupIndex][i] << endl;
            }

            string discussionTopic;
            cout << "Enter the discussion topic: ";
            cin.ignore(); // Ignore the newline character left in the buffer
            getline(cin, discussionTopic);
            cout << "Discussion Topic: " << discussionTopic << endl;

            int choice;
            string sender;
            string content;
            do
            {
                cout << "Peer Discussion Menu:" << endl;
                cout << "1. Post Message" << endl;
                cout << "2. View Messages" << endl;
                cout << "3. Exit" << endl;
                cout << "Enter your choice: ";
                cin >> choice;

                switch (choice)
                {
                case 1:
                {
                    cout << "Enter your name: ";
                    cin.ignore(); // Ignore the newline character left in the buffer
                    getline(cin, sender);
                    cout << "Enter your message: ";
                    getline(cin, content);
                    addMessageToGroup(groupID, sender, content);
                    break;
                }
                case 2:
                    displayMessages(groupID);
                    break;
                case 3:
                    cout << "Exiting Peer Discussion Menu." << endl;
                    break;
                default:
                    cout << "Invalid choice. Please try again." << endl;
                }
            } while (choice != 3);
        }
        else
        {
            cout << "Group not found." << endl;
        }
    }

    static void facilitateStudentCollaboration()
    {
        int groupID;
        cout << "Enter Group ID for student collaboration: ";
        cin >> groupID;

        int groupIndex = findGroupIndex(groupID);
        if (groupIndex != -1)
        {
            cout << "Facilitating Collaboration for Group: " << groupNames[groupIndex] << endl;
            cout << "Members:" << endl;
            for (int i = 0; i < memberCounts[groupIndex]; ++i)
            {
                cout << " - " << members[groupIndex][i] << endl;
            }

            string collaborationTask;
            cout << "Enter the collaboration task: ";
            cin.ignore();
            getline(cin, collaborationTask);
            cout << "Collaboration Task: " << collaborationTask << endl;

            int choice;
            do
            {
                cout << "Collaboration Menu:" << endl;
                cout << "1. Add Task" << endl;
                cout << "2. View Tasks" << endl;
                cout << "3. Mark Task as Completed" << endl;
                cout << "4. Exit" << endl;
                cout << "Enter your choice: ";
                cin >> choice;

                switch (choice)
                {
                case 1:
                {
                    string taskDesc;
                    string memberName;
                    cout << "Enter Task Description: ";
                    cin.ignore();
                    getline(cin, taskDesc);
                    cout << "Enter Member Name to Assign Task: ";
                    getline(cin, memberName);
                    addTaskToGroup(groupID, taskDesc, memberName);
                    break;
                }
                case 2:
                    displayTasks(groupID);
                    break;
                case 3:
                {
                    string memberName;
                    cout << "Enter Member Name to Mark Task as Completed: ";
                    cin.ignore();
                    getline(cin, memberName);
                    markTaskAsCompleted(groupID, memberName);
                    break;
                }
                case 4:
                    cout << "Exiting Collaboration Menu." << endl;
                    break;
                default:
                    cout << "Invalid choice. Please try again." << endl;
                }
            } while (choice != 4);
        }
        else
        {
            cout << "Group not found." << endl;
        }
    }

    static void addTaskToGroup(int groupID, const string& taskDesc, const string& memberName)
    {
        int groupIndex = findGroupIndex(groupID);
        if (groupIndex != -1 && taskCounts[groupIndex] < Constants::MAX_MEMBERS)
        {
            tasks[groupIndex][taskCounts[groupIndex]] = new Task(taskDesc, memberName);
            taskCounts[groupIndex]++;
            cout << "Task added to group: " << taskDesc << " assigned to " << memberName << endl;
        }
        else
        {
            cout << "Cannot add task to group." << endl;
        }
    }

    static void displayTasks(int groupID)
    {
        int groupIndex = findGroupIndex(groupID);
        if (groupIndex != -1)
        {
            cout << "Tasks for Group: " << groupNames[groupIndex] << endl;
            for (int i = 0; i < taskCounts[groupIndex]; ++i)
            {
                tasks[groupIndex][i]->displayTaskInfo();
            }
        }
        else
        {
            cout << "Group not found." << endl;
        }
    }

    static void markTaskAsCompleted(int groupID, const string& memberName)
    {
        int groupIndex = findGroupIndex(groupID);
        if (groupIndex != -1)
        {
            for (int i = 0; i < taskCounts[groupIndex]; ++i)
            {
                if (tasks[groupIndex][i]->getAssignedTo() == memberName)
                {
                    tasks[groupIndex][i]->markAsCompleted();
                    cout << "Task marked as completed for member: " << memberName << endl;
                    return;
                }
            }
            cout << "No tasks found for member: " << memberName << endl;
        }
        else
        {
            cout << "Group not found." << endl;
        }
    }

    static void addMessageToGroup(int groupID, const string& sender, const string& content)
    {
        int groupIndex = findGroupIndex(groupID);
        if (groupIndex != -1 && messageCounts[groupIndex] < Constants::MAX_MEMBERS)
        {
            messages[groupIndex][messageCounts[groupIndex]] = new Message(sender, content);
            messageCounts[groupIndex]++;
            cout << "Message posted by " << sender << " in group " << groupNames[groupIndex] << endl;
        }
        else
        {
            cout << "Cannot post message to group." << endl;
        }
    }

    static void displayMessages(int groupID)
    {
        int groupIndex = findGroupIndex(groupID);
        if (groupIndex != -1)
        {
            cout << "Messages for Group: " << groupNames[groupIndex] << endl;
            for (int i = 0; i < messageCounts[groupIndex]; ++i)
            {
                messages[groupIndex][i]->displayMessage();
            }
        }
        else
        {
            cout << "Group not found." << endl;
        }
    }

private:
    static int findGroupIndex(int groupID)
    {
        for (int i = 0; i < groupCount; ++i)
        {
            if (groupIDs[i] == groupID)
            {
                return i;
            }
        }
        return -1;
    }
};
// initialiling the members of group
int Group::groupCount = 0;
int Group::groupIDs[Constants::MAX_GROUPS] = { 0 };
string Group::groupNames[Constants::MAX_GROUPS] = { "" };
int Group::memberCounts[Constants::MAX_GROUPS] = { 0 };
string Group::members[Constants::MAX_GROUPS][Constants::MAX_MEMBERS] = { {} };
Task* Group::tasks[Constants::MAX_GROUPS][Constants::MAX_MEMBERS] = { nullptr };
int Group::taskCounts[Constants::MAX_GROUPS] = { 0 };
Message* Group::messages[Constants::MAX_GROUPS][Constants::MAX_MEMBERS] = { nullptr };
int Group::messageCounts[Constants::MAX_GROUPS] = { 0 };
#endif