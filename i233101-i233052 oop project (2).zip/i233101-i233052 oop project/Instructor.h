
#ifndef INSTRUCTOR_H
#define INSTRUCTOR_H

#include <iostream>
#include <fstream>
#include "Person.h"
#include "Student.h"
#include "Course.h"
#include "Notification.h"
#include "Assignment.h"
#include "Submission.h"
#include "Constants.h"

using namespace std;
// Derived Instructor class
class Instructor : public Person
{
private:
    string department;
    Course *assignedCourses[Constants::MAX_COURSES];
    Student *studentsInCourses[Constants::MAX_COURSES][Constants::MAX_STUDENTS];
    Assignment *assignments[Constants::MAX_COURSES][Constants::MAX_ASSIGNMENTS];
    Notification notifications[Constants::MAX_NOTIFICATIONS]; // Array to store notifications
    int notificationCount;                                    // Counter to keep track ofnotifications
    int courseCount;                                          // Counter to keep track of assigned courses
    int countOfStudents[Constants::MAX_COURSES];
    int assignmentCounts[Constants::MAX_COURSES];

public:
    // ---------------------------Operator overloading----------------------------
    bool operator==(const Instructor &obj) const
    {
        return (department == obj.department &&
                courseCount == obj.courseCount);
    }
    Instructor &operator=(const Instructor &obj)
    {
        if (this == &obj)
            return *this;

        department = obj.department;
        courseCount = obj.courseCount;

        for (int i = 0; i < courseCount; i++)
        {
            assignedCourses[i] = obj.assignedCourses[i];
            countOfStudents[i] = obj.countOfStudents[i];
            assignmentCounts[i] = obj.assignmentCounts[i];
            for (int j = 0; j < countOfStudents[i]; j++)
            {
                studentsInCourses[i][j] = obj.studentsInCourses[i][j];
            }
            for (int k = 0; k < assignmentCounts[i]; k++)
            {
                assignments[i][k] = obj.assignments[i][k];
            }
        }
        return *this;
    }

    friend istream &operator>>(istream &in, Instructor &obj)
    {
        cout << reset;

        cout << "Enter Department: ";
        in.ignore();
        getline(in, obj.department);
        cout << "Enter Number of Assigned Courses: ";
        in >> obj.courseCount;
        for (int i = 0; i < obj.courseCount; i++)
        {
            obj.assignedCourses[i] = new Course();
            in >> *(obj.assignedCourses[i]);
            cout << "Enter Number of Students in Course " << (i + 1) << ": ";
            in >> obj.countOfStudents[i];
            for (int j = 0; j < obj.countOfStudents[i]; j++)
            {
                obj.studentsInCourses[i][j] = new Student();
                in >> *(obj.studentsInCourses[i][j]);
            }
            cout << "Enter Number of Assignments in Course " << (i + 1) << ": ";
            in >> obj.assignmentCounts[i];
            for (int k = 0; k < obj.assignmentCounts[i]; k++)
            {
                obj.assignments[i][k] = new Assignment();
                in >> *(obj.assignments[i][k]);
            }
        }
        return in;
    }

    friend ostream &operator<<(ostream &out, const Instructor &obj)
    {
        cout << reset;

        out << "Department: " << obj.department << endl;
        out << "Assigned Courses: " << endl;
        for (int i = 0; i < obj.courseCount; i++)
        {
            out << obj.assignedCourses[i] << endl;
            out << "Students in Course: " << endl;
            for (int j = 0; j < obj.countOfStudents[i]; j++)
            {
                out << obj.studentsInCourses[i][j] << endl;
            }
            out << "Assignments in Course: " << endl;
            for (int k = 0; k < obj.assignmentCounts[i]; k++)
            {
                out << obj.assignments[i][k] << endl;
            }
        }
        return out;
    }
    string operator[](int index) const
    {
        switch (index)
        {
        case 0:
            return department;
        case 1:
            return to_string(courseCount);
        default:
            cout << reset;

            cout << "Invalid index!!!\n";
            return "";
        }
    }
    string operator()(const string &dataMember) const
    {
        if (dataMember == "department")
        {
            return department;
        }
        else if (dataMember == "courseCount")
        {
            return to_string(courseCount);
        }
        else
        {
            cout << reset;

            return "Invalid data member!";
        }
    }
    Instructor() : Person()
    {
        department = "";
        courseCount = 0;
        notificationCount = 0;
        for (int i = 0; i < Constants::MAX_COURSES; i++)
        {
            assignedCourses[i] = NULL;
            countOfStudents[i] = 0;
            assignmentCounts[i] = 0;
            for (int j = 0; j < Constants::MAX_STUDENTS; j++)
            {
                studentsInCourses[i][j] = NULL;
            }
            for (int k = 0; k < Constants::MAX_ASSIGNMENTS; k++)
            {
                assignments[i][k] = NULL;
            }
            assignmentCounts[i] = 5;
        }
    }
    // constructors
    Instructor(string name, int id, string email, string dept, int cCount) : Person(name, id, email)
    {
        this->department = dept;
        courseCount = cCount;
        notificationCount = 0;
        for (int i = 0; i < Constants::MAX_COURSES; i++)
        {
            assignedCourses[i] = NULL;
            countOfStudents[i] = 0;
            assignmentCounts[i] = 0;
            for (int j = 0; j < Constants::MAX_STUDENTS; j++)
            {
                studentsInCourses[i][j] = NULL;
            }

            for (int k = 0; k < Constants::MAX_ASSIGNMENTS; k++)
            {
                assignments[i][k] = NULL;
            }

            assignmentCounts[i] = 5;
        }
    }
    ~Instructor() {};
    // functions
    void displayInfo() override
    {
        cout << reset;

        cout << "Name: " << name << endl;
        cout << "Employee ID: " << ID << endl;
        cout << "Email: " << email << endl;
        cout << "Department: " << department << endl;
    }

    void DisplayInfo()
    {
        displayInfo();
    }

    string getRole() override
    {
        cout << reset;

        return "Instructor";
    }

    string GetRole()
    {
        return getRole();
    }

    void addCourse(Course *course)
    {
        if (!course) // Check if the provided course is null
        {
            cout << "Error: Cannot add a null course.\n";
            return;
        }

        if (courseCount < Constants::MAX_COURSES)
        {
            assignedCourses[courseCount++] = course;

            // Save course details to a binary file using Course's saveToFile method
            string filename = "coursee.bin";
            course->saveToFile(filename);

            cout << "Course '" << course->getCourseName() << "' added successfully...\nNow courses are :\n";
            course->displayFromFile(filename);
        }
        else
        {
            cout << "Maximum number of courses reached. Cannot assign more courses...\n";
        }
    }

    void addStudentsToCourse(Student *student, int cIndex)
    {
        if (cIndex >= 0 && cIndex < courseCount && countOfStudents[cIndex] < Constants::MAX_STUDENTS)
        {
            ++countOfStudents[cIndex];
            for (int i = 0; i < courseCount; i++)
            {
                for (int j = 0; j < countOfStudents[i]; j++)
                {
                    if (i == cIndex)
                    {
                        studentsInCourses[i][j] = student;
                        cout << reset;

                        cout << "Student '" << student->getName() << "' is added successfuly to the course... \n";
                        return;
                    }
                }
            }
        }

        else
            cout << reset;
        {
            cout << "Cannot add more students to course. " << endl;
        }
    }

    bool SendNotification(const Notification &notification)
    {
        return sendNotification(notification);
    }

    bool sendNotification(const Notification &notification) override
    {
        cout << reset;
        cout << "Sending Notification: " << endl;
        cout << "ID: " << notification.getNotificationId() << endl;
        cout << "Message: " << notification.getMessage() << endl;
        cout << "Date: " << notification.getDateSent() << endl;
        return true;
    }

    bool addNotification(const Notification &notification)
    {
        if (notificationCount < Constants::MAX_NOTIFICATIONS)
        {
            notifications[notificationCount] = notification;
            notificationCount++;
            cout << reset;

            cout << "Notification added successfully...\n";
            return true;
        }
        else
        {
            cout << reset;

            cout << "Notification limit reached for instructor " << name << endl;
            return false;
        }
    }

    void viewNotifications() const
    {
        for (int i = 0; i < notificationCount; i++)
        {
            notifications[i].displayNotificationInfo();
        }
    }

    void createAssignments(Course *course, Assignment *assignment)
    {
        // Check if the course or assignment is NULL
        if (course == NULL || assignment == NULL)
        {
            cout << "Error: Invalid course or assignment provided." << endl;
            return;
        }

        int courseIndex = -1;

        // Loop to find the course in assignedCourses
        for (int i = 0; i < courseCount; i++)
        {
            if (assignedCourses[i] != NULL && assignedCourses[i]->getCourseTitle() == course->getCourseTitle())
            {
                courseIndex = i;
                break;
            }
        }

        // Check if the course exists and if there's space for more assignments
        if (courseIndex != -1 && assignmentCounts[courseIndex] < Constants::MAX_ASSIGNMENTS)
        {
            assignments[courseIndex][assignmentCounts[courseIndex]] = assignment;
            ++assignmentCounts[courseIndex];
            cout << "Assignment created successfully for course: " << course->getCourseTitle() << endl;
            return;
        }
        else
        {
            cout << "Cannot create assignment for the specified course. Either the course does not exist or the maximum number of assignments has been reached." << endl;
        }
    }

    void gradeSubmissions(Student &student, Assignment &assignment, const string &grade)
    {
        for (int i = 0; i < courseCount; ++i)
        {
            for (int j = 0; j < countOfStudents[i]; ++j)
            {
                if (studentsInCourses[i][j] != NULL)
                {
                    if (student == (*(studentsInCourses[i][j])))
                    {
                        cout << student.getName() << endl;
                        cout << (studentsInCourses[i][j])->getName() << endl;
                        student.setGrade(assignment.getAssignmentID(), grade);
                        cout << reset;

                        cout << "Grade updated successfully for student: " << student.getName() << endl;
                        return;
                    }
                }
            }
        }
        cout << reset;

        cout << "Student not found in any course." << endl;
    }

    void monitorStudentProgress(Student &student)
    {
        bool studentFound = false;

        for (int i = 0; i < courseCount; ++i)
        {
            for (int j = 0; j < countOfStudents[i]; ++j)
            {
                if (studentsInCourses[i][j] != nullptr && *(studentsInCourses[i][j]) == student)
                {
                    studentFound = true;
                    cout << reset;

                    cout << "Monitoring progress for student: " << student.getName() << " in course: " << assignedCourses[i]->getCourseTitle() << endl;

                    // Display progress based on assignments
                    for (int k = 0; k < assignmentCounts[i]; ++k)
                    {
                        // Assignment assignment = *(assignments[i][k]);
                        if (assignments[i][k] != NULL)
                        {
                            string submissionStatus = student.getSubmissionStatus(assignments[i][k]->getAssignmentID());
                            cout << reset;
                            cout << "Assignment ID: " << assignments[i][k]->getAssignmentID()
                                 << ", Description: " << assignments[i][k]->getDescription()
                                 << ", Submission Status: " << submissionStatus
                                 << ", Grade: " << student.getGrade(assignments[i][k]->getAssignmentID())
                                 << endl;
                        }
                    }
                }
            }
        }

        if (!studentFound)
        {
            cout << reset;

            cout << "Student not found in any course." << endl;
        }
    }

    void issueCertificate(Student &student, Course &course)
    {
        bool studentFound = false;

        for (int i = 0; i < courseCount; ++i)
        {
            if (assignedCourses[i] == &course)
            {
                cout << YELLOW;
                cout << "Course found: " << course.getCourseTitle() << endl;
                for (int j = 0; j < countOfStudents[i]; ++j)
                {
                    if (studentsInCourses[i][j] != nullptr)
                    {
                        cout << "Checking student: " << studentsInCourses[i][j]->getName() << endl;
                        if (studentsInCourses[i][j]->getName() == student.getName())
                        {
                            cout << "s in courses: " << studentsInCourses[i][j]->getName() << endl;
                            studentFound = true;
                            break;
                        }
                    }
                }
            }
        }

        if (studentFound)
        {
            static int certificateCounter = 1;
            string issueDate;
            cout << "Enter the date of issuance of certificate (YYYY-MM-DD): ";
            cin >> issueDate;
            cout << "Certificate counter : " << certificateCounter << endl;
            Certificate certificate = course.generateCertificate(certificateCounter++, issueDate);

            if (student.addCertificate(certificate, certificateCounter))
            {
                cout << "Certificate issued successfully to student: " << student.getName()
                     << " for course: " << course.getCourseTitle() << endl;
            }
            else
            {
                cout << "Failed to issue certificate to student: " << student.getName()
                     << " for course: " << course.getCourseTitle() << endl;
            }
        }
        else
        {
            cout << "Student not found in the specified course." << endl;
        }
    }

    void setName(string n)
    {
        name = n;
    }
    string getName()
    {
        return name;
    }
    void setID(int id)
    {
        ID = id;
    }
    int getID()
    {
        return ID;
    }
    void setEmail(string e)
    {
        email = e;
    }
    string getEmail()
    {
        return email;
    }
    void setDepartment(string d)
    {
        department = d;
    }
    string getDepartment()
    {
        return department;
    }
};

#endif