#ifndef MESSAGE_H
#define MESSAGE_H

#include <iostream>
using namespace std;

// Class Message
class Message
{
private:
    string sender;  
    string content; 

public:
    // --------------------Operator overloading----------------------

    // Overloads the equality operator
    bool operator==(const Message &obj) const
    {
        return (sender == obj.sender && content == obj.content);
    }

    // Overloads the assignment operator
    
    Message &operator=(const Message &obj)
    {
        sender = obj.sender;
        content = obj.content;
        return *this;
    }

    // Overloads the input stream operator
    friend istream &operator>>(istream &in, Message &obj)
    {
        cout << "Enter Sender: ";
        in.ignore(); 
        getline(in, obj.sender);  
        cout << "Enter Content: ";
        getline(in, obj.content); 
        return in;
    }

    // Overloads the output stream operator
    friend ostream &operator<<(ostream &out, const Message &obj)
    {
        out << "Sender: " << obj.sender << endl;
        out << "Content: " << obj.content << endl;
        return out;
    }

    // Overloads the subscript operator
    string operator[](int index) const
    {
        switch (index)
        {
        case 0:
            return sender;
        case 1:
            return content;
        default: 
            cout << "Invalid index!!!\n";
            return "";
        }
    }

    // Overloads the function call 
    string operator()(const string &dataMember) const
    {
        if (dataMember == "sender")
        {
            return sender;  
        }
        else if (dataMember == "content")
        {
            return content; 
        }
        else
        {
            return "Invalid data member!";  
        }
    }

    // Default constructor 
    Message()
    {
        sender = "";
        content = "";
    }

    // Parameterized constructor initializes the sender and content with provided values
    Message(string sender, string content) : sender(sender), content(content) {}

    // Function to display the message details 
    void displayMessage() const
    {
        cout << "Sender: " << sender << endl;
        cout << "Content: " << content << endl;
    }

    // Function to get the sender's name
    string getSender() const
    {
        return sender;
    }
};

#endif
