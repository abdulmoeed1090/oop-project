#ifndef MODULE_H
#define MODULE_H

#include <iostream>
#include <fstream>
#include "Constants.h"
using namespace std;

// Class Module
class Module:public Notification
{
private:
    string moduleTitle;    
    int moduleID;
    string contentSections; 

public:
    // -----------------Operator overloading---------------------

    // Overloads the equality operator 
    bool operator==(const Module &obj) const
    {
        return (moduleTitle == obj.moduleTitle &&
                moduleID == obj.moduleID &&
                contentSections == obj.contentSections);
    }

    // Overloads the assignment operator 
    Module &operator=(const Module &obj)
    {
        moduleTitle = obj.moduleTitle;
        moduleID = obj.moduleID;
        contentSections = obj.contentSections;
        return *this;
    }

    // Overloads the input stream operator 
    friend istream &operator>>(istream &in, Module &obj)
    {
        cout << "Enter Module Title: ";
        in.ignore();  
        getline(in, obj.moduleTitle); 
        cout << "Enter Module ID: ";
        in >> obj.moduleID; 
        cout << "Enter Content Sections: ";
        in.ignore(); 

        getline(in, obj.contentSections); 
        return in;
    }

    // Overloads the output stream operator
    friend ostream &operator<<(ostream &out, const Module &obj)
    {
        out << "Module Title: " << obj.moduleTitle << endl;
        out << "Module ID: " << obj.moduleID << endl;
        out << "Content Sections: " << obj.contentSections << endl;
        return out;
    }

    // Overloads the subscript operator
    string operator[](int index) const
    {
        switch (index)
        {
        case 0:
            return moduleTitle;
        case 1:
            return to_string(moduleID);
        case 2:
            return contentSections;
        default:
            cout << "Invalid index!!!\n";
            return "";  
        }
    }

    // Overloads the function call operator 
    string operator()(const string &dataMember) const
    {
        if (dataMember == "moduleTitle")
        {
            return moduleTitle;
        }
        else if (dataMember == "moduleID")
        {
            return to_string(moduleID);
        }
        else if (dataMember == "contentSections")
        {
            return contentSections;
        }
        else
        {
            return "Invalid data member!"; 
        }
    }

    // Default constructor initializes data members to default values
    Module()
    {
        moduleTitle = "";
        moduleID = 0;
        contentSections = "";
    }

    // Parameterized constructor 
    Module(string title, int id, string sections)
    {
        moduleTitle = title;
        moduleID = id;
        contentSections = sections;
    }

    // Destructor 
    ~Module() {};

    // Function to display the module information
    void displayModuleInfo() const
    {
        cout << "Module Title : " << moduleTitle << endl;
        cout << "Module ID : " << moduleID << endl;
        cout << "Content sections : " << contentSections << endl;
    }

    // Getter and Setter functions for module data members

    void setModuleTitle(string title)
    {
        moduleTitle = title;
    }

    string getModuleTitle() const
    {
        return moduleTitle;
    }

    void setModuleId(int id)
    {
        moduleID = id;
    }

    int getModuleId() const
    {
        return moduleID;  
    }

    void setContentSections(string sections)
    {
        contentSections = sections;     }

    string getContentSections() const
    {
        return contentSections;  
    }
    // Method to write notification data to a binary file
    void writeToBinaryFile(ofstream &outFile) const
    {
        // Write message
        size_t msgSize = message.size();
        outFile.write(reinterpret_cast<const char*>(&msgSize), sizeof(msgSize));
        outFile.write(message.c_str(), msgSize);

        // Write date
        size_t dateSize = dateSent.size();
        outFile.write(reinterpret_cast<const char*>(&dateSize), sizeof(dateSize));
        outFile.write(dateSent.c_str(), dateSize);
    }

    // Method to read notification data from a binary file
    void readFromBinaryFile(ifstream &inFile)
    {
        // Read message
        size_t msgSize;
        inFile.read(reinterpret_cast<char*>(&msgSize), sizeof(msgSize));
        message.resize(msgSize);
        inFile.read(&message[0], msgSize);

        // Read date
        size_t dateSize;
        inFile.read(reinterpret_cast<char*>(&dateSize), sizeof(dateSize));
        dateSent.resize(dateSize);
        inFile.read(&dateSent[0], dateSize);
    }
};

#endif
