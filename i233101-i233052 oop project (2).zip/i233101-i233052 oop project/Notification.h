
#ifndef NOTIFICATION_H
#define NOTIFICATION_H

#include <iostream>
#include <fstream>
using namespace std;

// class notification
class Notification
{
public:
    // data members
    string message;
    int notificationID;
    string dateSent;

public:
    // -----------------Operator overloading------------------
    bool operator==(const Notification& obj) const
    {
        return (message == obj.message &&
            notificationID == obj.notificationID &&
            dateSent == obj.dateSent);
    }
    Notification& operator=(const Notification& obj)
    {
        message = obj.message;
        notificationID = obj.notificationID;
        dateSent = obj.dateSent;
        return *this;
    }
    friend istream& operator>>(istream& in, Notification& obj)
    {
        cout << "Enter Notification ID: ";
        in >> obj.notificationID;
        cout << "Enter Notification message: ";
        in.ignore();
        getline(in, obj.message);
        cout << "Enter Notification date sent: ";
        getline(in, obj.dateSent);
        return in;
    }
    friend ostream& operator<<(ostream& out, const Notification& obj)
    {
        out << "Notification ID: " << obj.notificationID << endl;
        out << "Notification message: " << obj.message << endl;
        out << "Notification date sent: " << obj.dateSent << endl;
        return out;
    }
    string operator[](int index) const
    {
        switch (index)
        {
        case 0:
            return to_string(notificationID);
        case 1:
            return message;
        case 2:
            return dateSent;
        default:
            cout << "Invalid index!!!\n";
            return "";
        }
    }
    string operator()(const string& dataMember) const
    {
        if (dataMember == "notificationID")
        {
            return to_string(notificationID);
        }
        else if (dataMember == "message")
        {
            return message;
        }
        else if (dataMember == "dateSent")
        {
            return dateSent;
        }
        else
        {
            return "Invalid data member!";
        }
    }
    // constructors
    Notification()
    {
        message = "";
        notificationID = 0;
        dateSent="";
    }

    Notification(string message, int notificationID,string dateSent)
    {
        this->message = message;
        this->notificationID = notificationID;
        this->dateSent=dateSent;
    }
    // getter setter
    void setMessage(string message)
    {
        this->message = message;
    }
    string getMessage() const
    {
        return this->message;
    }
    void setNotificationId(int notificationID)
    {
        this->notificationID = notificationID;
    }
    int getNotificationId() const
    {
        return notificationID;
    }
    string getDateSent() const
    {
        return dateSent;
    }
    // functionss
    void displayNotificationInfo() const
    {
        cout << "Notification message : " << message << endl;
        cout << "Notification ID : " << notificationID << endl;
    }
     void writeToBinaryFile(ofstream &outFile) const
    {
        // Write notificationID
        outFile.write(reinterpret_cast<const char*>(&notificationID), sizeof(notificationID));

        // Write message
        size_t msgSize = message.size();
        outFile.write(reinterpret_cast<const char*>(&msgSize), sizeof(msgSize));
        outFile.write(message.c_str(), msgSize);

        // Write dateSent
        size_t dateSize = dateSent.size();
        outFile.write(reinterpret_cast<const char*>(&dateSize), sizeof(dateSize));
        outFile.write(dateSent.c_str(), dateSize);
    }

    // Method to read notification data from a binary file
    void readFromBinaryFile(ifstream &inFile)
    {
        // Read notificationID
        inFile.read(reinterpret_cast<char*>(&notificationID), sizeof(notificationID));

        // Read message
        size_t msgSize;
        inFile.read(reinterpret_cast<char*>(&msgSize), sizeof(msgSize));
        message.resize(msgSize);
        inFile.read(&message[0], msgSize);

        // Read dateSent
        size_t dateSize;
        inFile.read(reinterpret_cast<char*>(&dateSize), sizeof(dateSize));
        dateSent.resize(dateSize);
        inFile.read(&dateSent[0], dateSize);
    }
};
#endif