#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>
#include <fstream>
#include "Person.h"
#include "Course.h"
#include "Notification.h"
#include "Assignment.h"
#include "Certificate.h"
#include "Submission.h"
#include "Constants.h"

using namespace std;

// Derived Student class
class Student : public Person
{
private:
    int studentID;
    string enrollmentDate;
    Course *completedCourses;
    Course *enrolledCourses;
    Notification notifications[Constants::MAX_NOTIFICATIONS];
    Assignment assignments[Constants::MAX_ASSIGNMENTS];
    Certificate *certificates;
    Submission submissions[Constants::MAX_SUBMISSIONS];
    int assignmentIDs[Constants::MAX_SUBMISSIONS];
    int groupIDs[Constants::MAX_GROUPS];              // Array to store group IDs the student is part of
    int assessmentScores[Constants::MAX_ASSESSMENTS]; // Array to store assessment scores
    int assessmentIDs[Constants::MAX_ASSESSMENTS];    // Array to store assessment IDs
    int assessmentCount;                              // Counter to keep track of the number of assessments
    int certificateCount;
    int groupCount; // Counter to keep track of the number of groups the student is part of
    int assignmentCount;
    int notificationCount;
    int courseCount;
    int enrolledCoursesCount;

public:
    //------------------ operator overloading ------------------
    bool operator==(const Student &obj) const
    {
        return (studentID == obj.studentID &&
                enrollmentDate == obj.enrollmentDate &&
                courseCount == obj.courseCount &&
                enrolledCoursesCount == obj.enrolledCoursesCount &&
                notificationCount == obj.notificationCount &&
                assignmentCount == obj.assignmentCount &&
                certificateCount == obj.certificateCount &&
                groupCount == obj.groupCount);
    }
    Student &operator=(const Student &obj)
    {
        if (this == &obj) // Check for self-assignment
            return *this;

        // Copy basic types
        studentID = obj.studentID;
        enrollmentDate = obj.enrollmentDate;
        courseCount = obj.courseCount;
        enrolledCoursesCount = obj.enrolledCoursesCount;
        notificationCount = obj.notificationCount;
        assignmentCount = obj.assignmentCount;
        certificateCount = obj.certificateCount;
        groupCount = obj.groupCount;

        // Delete old arrays to prevent memory leaks
        delete[] completedCourses;
        delete[] enrolledCourses;
        delete[] certificates;

        // Deep copy dynamically allocated arrays
        completedCourses = new Course[courseCount]; // allocate new memory for completedCourses
        for (int i = 0; i < courseCount; i++)
        {
            completedCourses[i] = obj.completedCourses[i];
        }

        enrolledCourses = new Course[enrolledCoursesCount]; // allocate new memory for enrolledCourses
        for (int i = 0; i < enrolledCoursesCount; i++)
        {
            enrolledCourses[i] = obj.enrolledCourses[i];
        }

        certificates = new Certificate[certificateCount]; // allocate new memory for certificates
        for (int i = 0; i < certificateCount; i++)
        {
            certificates[i] = obj.certificates[i];
        }

        // Copy other arrays
        for (int i = 0; i < notificationCount; i++)
        {
            notifications[i] = obj.notifications[i];
        }

        for (int i = 0; i < assignmentCount; i++)
        {
            assignments[i] = obj.assignments[i];
        }

        for (int i = 0; i < Constants::MAX_SUBMISSIONS; i++)
        {
            submissions[i] = obj.submissions[i];
            assignmentIDs[i] = obj.assignmentIDs[i];
        }

        for (int i = 0; i < groupCount; i++)
        {
            groupIDs[i] = obj.groupIDs[i];
        }

        return *this;
    }

    friend istream &operator>>(istream &in, Student &obj)
    {
        cout << "Enter the name of the student: ";
        cin.ignore();
        getline(cin, obj.name);

        cout << "Enter Student ID: ";
        in >> obj.studentID;

        cout << "Enter the student's email id: ";
        cin.ignore();
        getline(cin, obj.email);

        cout << "Enter Enrollment Date: ";
        in.ignore();
        getline(in, obj.enrollmentDate);

        cout << "Enter Number of Completed Courses: ";
        in >> obj.courseCount;

        while (obj.courseCount < 0)
        {
            cout << "Invalid input!!!\nEnter again: ";
            cin >> obj.courseCount;
        }

        obj.completedCourses = new Course[obj.courseCount];
        for (int i = 0; i < obj.courseCount; i++)
        {
            cout << "Enter for course " << i + 1 << endl;
            in >> obj.completedCourses[i];
        }

        cout << "Enter Number of Enrolled Courses: ";
        in >> obj.enrolledCoursesCount;

        while (obj.enrolledCoursesCount < 0 || obj.enrolledCoursesCount > Constants::MAX_COURSES)
        {
            cout << "Invalid input!!!\nEnter again: ";
            cin >> obj.enrolledCoursesCount;
        }

        obj.enrolledCourses = new Course[obj.enrolledCoursesCount + 2];

        for (int i = 0; i < obj.enrolledCoursesCount; i++)
        {
            cout << "Enter the details for course " << i + 1 << ": " << endl;
            in >> obj.enrolledCourses[i];
        }

        cout << "Enter Number of Notifications: ";
        in >> obj.notificationCount;

        while (obj.notificationCount < 0 || obj.notificationCount > Constants::MAX_NOTIFICATIONS)
        {
            cout << "Invalid input!!!\nEnter again: ";
            cin >> obj.notificationCount;
        }

        for (int i = 0; i < obj.notificationCount; i++)
        {
            cout << "Notification " << i + 1 << ": " << endl;
            in >> obj.notifications[i];
        }

        cout << "Enter Number of Assignments: ";
        in >> obj.assignmentCount;

        while (obj.assignmentCount < 0 || obj.assignmentCount > Constants::MAX_ASSIGNMENTS)
        {
            cout << "Invalid input!!!\nEnter again: ";
            cin >> obj.assignmentCount;
        }

        for (int i = 0; i < obj.assignmentCount; i++)
        {
            in >> obj.assignments[i];
        }

        cout << "Enter Number of Certificates: ";
        in >> obj.certificateCount;

        while (obj.certificateCount < 0 || obj.certificateCount > Constants::MAX_CERTIFICATES)
        {
            cout << "Invalid input!!!\nEnter again: ";
            cin >> obj.certificateCount;
        }

        obj.certificates = new Certificate[obj.certificateCount];

        for (int i = 0; i < obj.certificateCount; i++)
        {
            cout << "Enter for certificate " << i + 1 << ": " << endl;
            in >> obj.certificates[i];
        }

        cout << "Enter Number of Groups: ";
        in >> obj.groupCount;

        while (obj.groupCount < 0 || obj.groupCount > Constants::MAX_GROUPS)
        {
            cout << "Invalid input!!!\nEnter again: ";
            cin >> obj.groupCount;
        }

        cout << "Enter the group IDs: " << endl;
        for (int i = 0; i < obj.groupCount; i++)
        {
            in >> obj.groupIDs[i];
        }
        return in;
    }
    friend ostream &operator<<(ostream &out, const Student &obj)
    {
        out << "Name: " << obj.name << endl;
        out << "Email: " << obj.email << endl;
        out << "Student ID: " << obj.studentID << endl;
        out << "Enrollment Date: " << obj.enrollmentDate << endl;
        out << "Completed Courses: " << endl;

        for (int i = 0; i < obj.courseCount; i++)
        {
            out << obj.completedCourses[i] << endl;
        }

        out << "Enrolled Courses: " << endl;
        for (int i = 0; i < obj.enrolledCoursesCount; i++)
        {
            out << obj.enrolledCourses[i] << endl;
        }

        out << "Notifications: " << endl;
        for (int i = 0; i < obj.notificationCount; i++)
        {
            out << obj.notifications[i] << endl;
        }

        out << "Assignments: " << endl;
        for (int i = 0; i < obj.assignmentCount; i++)
        {
            out << obj.assignments[i] << endl;
        }

        out << "Certificates: " << endl;
        for (int i = 0; i < obj.certificateCount; i++)
        {
            out << obj.certificates[i] << endl;
        }

        out << "Groups: " << endl;
        for (int i = 0; i < obj.groupCount; i++)
        {
            out << obj.groupIDs[i] << endl;
        }

        return out;
    }
    string operator[](int index) const
    {
        switch (index)
        {
        case 0:
            return to_string(studentID);
        case 1:
            return enrollmentDate;
        case 2:
            return to_string(courseCount);
        case 3:
            return to_string(enrolledCoursesCount);
        case 4:
            return to_string(notificationCount);
        case 5:
            return to_string(assignmentCount);
        case 6:
            return to_string(certificateCount);
        case 7:
            return to_string(groupCount);
        default:
            cout << "Invalid index!!!\n";
            return "";
        }
    }
    string operator()(const string &dataMember) const
    {
        if (dataMember == "studentID")
        {
            return to_string(studentID);
        }
        else if (dataMember == "enrollmentDate")
        {
            return enrollmentDate;
        }
        else if (dataMember == "courseCount")
        {
            return to_string(courseCount);
        }
        else if (dataMember == "enrolledCoursesCount")
        {
            return to_string(enrolledCoursesCount);
        }
        else if (dataMember == "notificationCount")
        {
            return to_string(notificationCount);
        }
        else if (dataMember == "assignmentCount")
        {
            return to_string(assignmentCount);
        }
        else if (dataMember == "certificateCount")
        {
            return to_string(certificateCount);
        }
        else if (dataMember == "groupCount")
        {
            return to_string(groupCount);
        }
        else
        {
            return "Invalid data member!";
        }
    }
    // Union operator to get all courses from both students
    void operator|(const Student &other) const
    {
        Student result;                                                                         // Use the provided constructor
        result.enrolledCourses = new Course[enrolledCoursesCount + other.enrolledCoursesCount]; // Allocate memory for courses
        result.enrolledCoursesCount = 0;

        // Copy current student's courses to the result
        for (int i = 0; i < enrolledCoursesCount; i++)
        {
            result.enrolledCourses[result.enrolledCoursesCount++] = enrolledCourses[i];
        }

        // Add courses from the other student if not already in result
        for (int i = 0; i < other.enrolledCoursesCount; i++)
        {
            bool alreadyAdded = false;
            for (int j = 0; j < enrolledCoursesCount; j++)
            {
                if (enrolledCourses[j].getCourseCode() == other.enrolledCourses[i].getCourseCode())
                {
                    alreadyAdded = true;
                    break;
                }
            }
            if (!alreadyAdded && result.enrolledCoursesCount < enrolledCoursesCount + other.enrolledCoursesCount)
            {
                result.enrolledCourses[result.enrolledCoursesCount++] = other.enrolledCourses[i];
            }
        }
        cout << BLUE;
        cout << "Union of courses : \n";
        result.displayEnrolledCourses();
    }

    // Intersection operator to get common courses from both students
    void operator&(const Student &other) const
    {
        Student result;
        result.enrolledCoursesCount = 0;
        if (enrolledCoursesCount < other.enrolledCoursesCount)
        {
            result.enrolledCourses = new Course[enrolledCoursesCount];
        }

        else
        {
            result.enrolledCourses = new Course[other.enrolledCoursesCount];
        }

        for (int i = 0; i < enrolledCoursesCount; i++)
        {
            for (int j = 0; j < other.enrolledCoursesCount; j++)
            {
                if (enrolledCourses[i].getCourseCode() == other.enrolledCourses[j].getCourseCode())
                {
                    result.enrolledCourses[result.enrolledCoursesCount++] = enrolledCourses[i];
                    break;
                }
            }
        }
        cout << BLUE;
        cout << "Intersection of courses : \n";
        result.displayEnrolledCourses();
    }

    // constructors
    Student()
    {
        name = "";
        studentID = 0;
        email = "";
        completedCourses = NULL;
        assignmentIDs[Constants::MAX_SUBMISSIONS] = 0;
        groupIDs[Constants::MAX_GROUPS] = 0;
        assessmentScores[Constants::MAX_ASSESSMENTS] = 0;
        assessmentIDs[Constants::MAX_ASSESSMENTS] = 0;
        assessmentCount = 0;
        certificateCount = 0;
        groupCount = 0;
        assignmentCount = 0;
        notificationCount = 0;
        courseCount = 0;
        enrolledCoursesCount = 0;
        certificates=new Certificate[0];
    }
    Student(string name, int ID, string email, int studentId, string enrollmentDate, int coursesCompletedCount, int certificateCount) : Person(name, ID, email)
    {
        this->studentID = studentID;
        this->enrollmentDate = enrollmentDate;
        certificates=new Certificate[certificateCount];

        // completedCourses = new Course[coursesCompletedCount];
        // cout << "Enter the details of the courses you have completed: " << endl;
        //  for (int i = 0; i < coursesCompletedCount; i++)
        //  {
        //  completedCourses[i] = NULL;
        // }

        // certificates = new Certificate[certificateCount];
        // cout << "Enter the details of the certificates you have gotten: " << endl;
        //  for (int i = 0; i < certificateCount; i++)
        //  {
        //  cin >> certificates[i];
        // }
        courseCount = coursesCompletedCount;
        assignmentIDs[Constants::MAX_SUBMISSIONS] = 0;
        groupIDs[Constants::MAX_GROUPS] = 0;
        assessmentScores[Constants::MAX_ASSESSMENTS] = 0;
        assessmentIDs[Constants::MAX_ASSESSMENTS] = 0;
        assessmentCount = 0;
        this->certificateCount = certificateCount;
        groupCount = 0;
        assignmentCount = 0;
        notificationCount = 0;
        courseCount = 0;
        enrolledCoursesCount = 0;
    }

    Student(const Student &student)
    {
        name = student.name;
        studentID = student.studentID;
        enrollmentDate = student.enrollmentDate;
        completedCourses = new Course[student.courseCount];
        for (int i = 0; i < student.courseCount; i++)
        {
            completedCourses[i] = student.completedCourses[i];
        }
        courseCount = student.courseCount;

        enrolledCoursesCount = student.enrolledCoursesCount;
        for (int i = 0; i < student.enrolledCoursesCount; i++)
        {
            enrolledCourses[i] = student.enrolledCourses[i];
        }
    }
    ~Student() {
    delete[] completedCourses;
    completedCourses = nullptr;  // Avoid dangling pointer
    delete[] enrolledCourses;
    enrolledCourses = nullptr;  // Avoid dangling pointer
    delete[] certificates;
    certificates = nullptr;  // Avoid dangling pointer
}

    string getName() const
    {
        return name;
    }

    void displayInfo() override
    {
        cout << "---Student's Information--- " << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << studentID << endl;
        cout << "Email: " << email << endl;
        cout << "Enrollment Date: " << enrollmentDate << endl;
        cout << "Courses Details: " << endl;
        cout << "Courses completed: " << courseCount << endl;
        for (int i = 0; i < courseCount; i++)
        {
            cout << "Course # " << i + 1 << " : " << endl;
            completedCourses[i].displayCourseInfo();
        }

        cout << "Enrolled courses: " << enrolledCoursesCount << endl;
        for (int i = 0; i < enrolledCoursesCount; i++)
        {
            cout << "Course # " << i + 1 << " : " << endl;
            enrolledCourses[i].displayCourseInfo();
        }
    }

    void displayEnrolledCourses()
    {
        for (int i = 0; i < enrolledCoursesCount; i++)
        {
            cout << "Course " << i + 1 << ": " << endl;
            cout << enrolledCourses[i];
        }
    }
    string getRole() override
    {
        return "Student";
    }
    bool sendNotification(const Notification &notification) override
    {
        cout << "Notification for Student: " << name << " (Student ID: " << studentID << ")\nMessage: " << notification.getMessage() << endl;
        return true;
    }

    bool addNotification(const Notification &notification)
    {
        if (notificationCount < Constants::MAX_NOTIFICATIONS)
        {
            notifications[notificationCount] = notification;
            notificationCount++;
            return true;
        }
        else
        {
            cout << "Notification limit reached for student " << name << endl;
            return false;
        }
    }

    void viewNotifications() const
    {
        if (notificationCount == 0)
        {
            cout << "No notifications of assignments, quizzes, projects and exams " << endl;
        }
        for (int i = 0; i < notificationCount; i++)
        {
            notifications[i].displayNotificationInfo();
        }
    }

    void enrollInCourse(Course &course)
    {
        if (enrolledCoursesCount < Constants::MAX_COURSES)
        {
            enrolledCourses[enrolledCoursesCount++] = course;
            cout << name << " you are enrolled in " << course.getCourseName() << endl;
        }
        else
        {
            cout << "Maximum number of courses reached for student " << name << endl;
        }
    }

    bool addAssignment(const Assignment &assignment)
    {
        if (assignmentCount < Constants::MAX_ASSIGNMENTS)
        {
            assignments[assignmentCount] = assignment;
            assignmentIDs[assignmentCount] = assignment.getAssignmentID();
            assignmentCount++;
            return true;
        }
        else
        {
            cout << "Assignment limit reached for student " << name << endl;
            return false;
        }
    }

    void viewAssignments()
    {
        if (assignmentCount == 0)
        {
            cout << "No assignments due " << endl;
            return;
        }
        for (int i = 0; i < assignmentCount; i++)
        {
            assignments[i].displayAssignmentInfo();
        }
    }

    bool submitAssignment(const Assignment &assignment)
    {
        if (assignmentCount == 0)
        {
            cout << "No assignments due. So, you can't submit assignment " << endl;
            return false;
        }

        for (int i = 0; i < assignmentCount; i++)
        {
            if (assignments[i].getAssignmentID() == assignment.getAssignmentID())
            {
                assignments[i].setSubmission("Submitted");
                cout << "Assignment " << assignment.getAssignmentID() << " submitted successfully by " << name << endl;
                return true;
            }
        }

        cout << "Assignment ID " << assignment.getAssignmentID() << " not found for student " << name << endl;
        return false;
    }

    int getAssignmentMarks(Assignment &assignment)
    {
        int assignmentWeightage = 5;
        if (assignment.getSubmission() == "Submitted")
        {
            assignment.setMaxScore(30);
            cout << "Marks: " << assignment.getMaxScore();
            return assignment.getMaxScore() / assignment.getTotalMarks() * assignmentWeightage;
        }

        else
        {
            return 0;
        }
    }

    void setGrade(const int assignmentID, const string &grade)
    {
        for (int i = 0; i < Constants::MAX_SUBMISSIONS; ++i)
        {
            if (assignmentIDs[i] == assignmentID)
            {
                submissions[i].setGrade(grade);
                break;
            }
        }
    }

    string getGrade(const int assignmentID) const
    {
        for (int i = 0; i < Constants::MAX_SUBMISSIONS; ++i)
        {
            if (assignmentIDs[i] == assignmentID)
            {
                return submissions[i].getGrade();
            }
        }
        return "No grade available";
    }

    string getSubmissionStatus(int assignmentID) const
    {
        for (int i = 0; i < assignmentCount; ++i)
        {
            if (assignments[i].getAssignmentID() == assignmentID)
            {
                return assignments[i].getSubmission().empty() ? "Not Submitted" : "Submitted";
            }
        }
        return "Assignment not found";
    }

    void addScore(int assessmentID, int score)
    {
        if (assessmentCount < Constants::MAX_ASSESSMENTS)
        {
            assessmentScores[assessmentCount] = score;
            assessmentCount++;
        }
        else
        {
            cout << "Assessment score limit reached for student " << name << endl;
        }
    }

    int getScore(int assessmentID) const
    {
        for (int i = 0; i < assessmentCount; i++)
        {
            if (assessmentIDs[i] == assessmentID)
            {
                return assessmentScores[i];
            }
        }
        return -1;
    }

    void checkProgress()
    {
        cout << "Progress for student " << name << ":\n";
        for (int i = 0; i < assignmentCount; i++)
        {
            cout << "Assignment ID: " << assignments[i].getAssignmentID()
                 << ", Description: " << assignments[i].getDescription()
                 << ", Submission Status: "
                 << (assignments[i].getSubmission().empty() ? "Not Submitted" : "Submitted")
                 << endl;
        }
    }

    bool addCertificate(const Certificate &certificate, int count)
    {
        certificateCount = count;
        if (certificateCount < Constants::MAX_CERTIFICATES)
        {
            certificates[certificateCount] = certificate;
            certificateCount++;
            return true;
        }
        else
        {
            cerr << "Certificate limit reached for student " << name << endl;
            return false;
        }
    }

    void viewCertifications() const
    {
        if (certificateCount == 0)
        {
            cout << "You did not get any certificates " << endl;
            return;
        }

        cout << "Certifications for student " << name << ":\n";
        for (int i = 0; i < certificateCount; i++)
        {
            certificates[i].displayCertificateInfo();
            cout << certificateCount << endl;
            cout << "------------------------" << endl;
        }
    }

    bool joinGroup(int groupID)
    {
        if (groupCount < Constants::MAX_GROUPS)
        {
            groupIDs[groupCount] = groupID;
            groupCount++;
            cout << "You have been added successfully to the group with ID: " << groupID << endl;
            return true;
        }
        else
        {
            cout << "Maximum number of groups reached for student " << name << endl;
            return false;
        }
    }

    bool leaveGroup(int groupID)
    {
        for (int i = 0; i < groupCount; i++)
        {
            if (groupIDs[i] == groupID)
            {
                // Shift the remaining groups to fill the gap
                for (int j = i; j < groupCount - 1; j++)
                {
                    groupIDs[j] = groupIDs[j + 1];
                }
                groupCount--;
                cout << "You have been successfully removed from the group " << endl;
                return true;
            }
        }
        cout << "Group not found for student " << name << endl;
        return false;
    }

    // Method to display groups the student is part of
    void displayGroups() const
    {
        cout << "Groups for student " << name << ":\n";
        for (int i = 0; i < groupCount; i++)
        {
            cout << "Group ID: " << groupIDs[i] << endl;
        }
    }

    // Method to write student data to a binary file
    bool writeToBinaryFile(const string &filename) const
    {
        ofstream outFile(filename, ios::binary);
        if (!outFile)
        {
            cerr << "Error opening file for writing: " << filename << endl;
            return false;
        }

        // Write basic data
        outFile.write(reinterpret_cast<const char*>(&studentID), sizeof(studentID));
        size_t len = enrollmentDate.size();
        outFile.write(reinterpret_cast<const char*>(&len), sizeof(len));
        outFile.write(enrollmentDate.c_str(), len);

        outFile.write(reinterpret_cast<const char*>(&courseCount), sizeof(courseCount));
        outFile.write(reinterpret_cast<const char*>(&enrolledCoursesCount), sizeof(enrolledCoursesCount));
        outFile.write(reinterpret_cast<const char*>(&notificationCount), sizeof(notificationCount));
        outFile.write(reinterpret_cast<const char*>(&assignmentCount), sizeof(assignmentCount));
        outFile.write(reinterpret_cast<const char*>(&certificateCount), sizeof(certificateCount));
        outFile.write(reinterpret_cast<const char*>(&groupCount), sizeof(groupCount));

        // Write completed courses
        for (int i = 0; i < courseCount; i++)
        {
            completedCourses[i].writeToBinaryFile(outFile);
        }

        // Write enrolled courses
        for (int i = 0; i < enrolledCoursesCount; i++)
        {
            enrolledCourses[i].writeToBinaryFile(outFile);
        }

        // Write notifications
        for (int i = 0; i < notificationCount; i++)
        {
            notifications[i].writeToBinaryFile(outFile);
        }

        // Write assignments
        for (int i = 0; i < assignmentCount; i++)
        {
            assignments[i].writeToBinaryFile(outFile);
        }

        // Write certificates
        // for (int i = 0; i < certificateCount; i++)
        // {
        //    // certificates[i].writeToBinaryFile(outFile);
        // }

        // Write group IDs
        for (int i = 0; i < groupCount; i++)
        {
            outFile.write(reinterpret_cast<const char*>(&groupIDs[i]), sizeof(groupIDs[i]));
        }

        outFile.close();
        return true;
    }

    // Method to read student data from a binary file
    bool readFromBinaryFile(const string &filename)
    {
        ifstream inFile(filename, ios::binary);
        if (!inFile)
        {
            cerr << "Error opening file for reading: " << filename << endl;
            return false;
        }

        // Read basic data
        inFile.read(reinterpret_cast<char*>(&studentID), sizeof(studentID));
        size_t len;
        inFile.read(reinterpret_cast<char*>(&len), sizeof(len));
        enrollmentDate.resize(len);
        inFile.read(&enrollmentDate[0], len);

        inFile.read(reinterpret_cast<char*>(&courseCount), sizeof(courseCount));
        inFile.read(reinterpret_cast<char*>(&enrolledCoursesCount), sizeof(enrolledCoursesCount));
        inFile.read(reinterpret_cast<char*>(&notificationCount), sizeof(notificationCount));
        inFile.read(reinterpret_cast<char*>(&assignmentCount), sizeof(assignmentCount));
        inFile.read(reinterpret_cast<char*>(&certificateCount), sizeof(certificateCount));
        inFile.read(reinterpret_cast<char*>(&groupCount), sizeof(groupCount));

        // Read completed courses
        completedCourses = new Course[courseCount];
        for (int i = 0; i < courseCount; i++)
        {
            completedCourses[i].readFromBinaryFile(inFile);
        }

        // Read enrolled courses
        enrolledCourses = new Course[enrolledCoursesCount];
        for (int i = 0; i < enrolledCoursesCount; i++)
        {
            enrolledCourses[i].readFromBinaryFile(inFile);
        }

        // Read notifications
        for (int i = 0; i < notificationCount; i++)
        {
            notifications[i].readFromBinaryFile(inFile);
        }

        // Read assignments
        for (int i = 0; i < assignmentCount; i++)
        {
            assignments[i].readFromBinaryFile(inFile);
        }

        // Read certificates
        // certificates = new Certificate[certificateCount];
        // for (int i = 0; i < certificateCount; i++)
        // {
        //     certificates[i].readFromBinaryFile(inFile);
        // }

        // Read group IDs
        for (int i = 0; i < groupCount; i++)
        {
            inFile.read(reinterpret_cast<char*>(&groupIDs[i]), sizeof(groupIDs[i]));
        }

        inFile.close();
        return true;
    }
};

#endif
