
#ifndef SUBMISSION_H
#define SUBMISSION_H

#include <iostream>
using namespace std;
// class submission
class Submission
{
private:
    string grade;

public:
    // ------------------Operator overloading---------------
    bool operator==(const Submission& obj) const
    {
        return (grade == obj.grade);
    }
    Submission& operator=(const Submission& obj)
    {
        grade = obj.grade;
        return *this;
    }
    friend istream& operator>>(istream& in, Submission& obj)
    {
        cout << "Enter Grade: ";
        in >> obj.grade;
        return in;
    }
    friend ostream& operator<<(ostream& out, const Submission& obj)
    {
        out << "Grade: " << obj.grade << endl;
        return out;
    }
    string operator[](int index) const
    {
        if (index == 0)
        {
            return grade;
        }
        else
        {
            cout << "Invalid index!!!\n";
            return "";
        }
    }
    string operator()(const string& dataMember) const
    {
        if (dataMember == "grade")
        {
            return grade;
        }
        else
        {
            return "Invalid data member!";
        }
    }
    // default constructor
    Submission() : grade("") {}

    // getter setters
    void setGrade(const string& grade)
    {
        this->grade = grade;
    }

    string getGrade() const
    {
        return grade;
    }
};

#endif