

#ifndef TASK_H
#define TASK_H

#include <iostream>
class Task
{
private:
    string description;
    string assignedTo;
    bool completed;

public:
    // ------------------Operator overloading---------------------
    bool operator==(const Task& obj) const
    {
        return (description == obj.description &&
            assignedTo == obj.assignedTo &&
            completed == obj.completed);
    }
    Task& operator=(const Task& obj)
    {
        description = obj.description;
        assignedTo = obj.assignedTo;
        completed = obj.completed;
        return *this;
    }
    friend istream& operator>>(istream& in, Task& obj)
    {
        cout << "Enter Task Description: ";
        in.ignore();
        getline(in, obj.description);
        cout << "Enter Assigned To: ";
        getline(in, obj.assignedTo);
        cout << "Is task completed press(1 for yes, 0 for no): ";
        in >> obj.completed;
        return in;
    }
    friend ostream& operator<<(ostream& out, const Task& obj)
    {
        out << "Task Description: " << obj.description << endl;
        out << "Assigned To: " << obj.assignedTo << endl;
        out << "Completed: " << (obj.completed ? "Yes" : "No") << endl;
        return out;
    }
    string operator[](int index) const
    {
        switch (index)
        {
        case 0:
            return description;
        case 1:
            return assignedTo;
        case 2:
            return completed ? "Yes" : "No";
        default:
            cout << "Invalid index!!!\n";
            return "";
        }
    }
    string operator()(const string& dataMember) const
    {
        if (dataMember == "description")
        {
            return description;
        }
        else if (dataMember == "assignedTo")
        {
            return assignedTo;
        }
        else if (dataMember == "completed")
        {
            return completed ? "Yes" : "No";
        }
        else
        {
            return "Invalid data member!";
        }
    }
    // constructors
    Task()
    {
        description = "";
        assignedTo = "";
        completed = false;
    }
    Task(string desc, string member) : description(desc), assignedTo(member), completed(false) {}

    void displayTaskInfo() const
    {
        cout << "Task Description: " << description << endl;
        cout << "Assigned To: " << assignedTo << endl;
        cout << "Completed: " << (completed ? "Yes" : "No") << endl;
    }

    void markAsCompleted()
    {
        completed = true;
    }

    string getAssignedTo() const
    {
        return assignedTo;
    }
};


#endif