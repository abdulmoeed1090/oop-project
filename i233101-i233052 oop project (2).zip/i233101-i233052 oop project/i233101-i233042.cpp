#include <iostream>
#include "Person.h"
#include "Course.h"
#include "Notification.h"
#include "Assignment.h"
#include "Certificate.h"
#include "Submission.h"
#include "Constants.h"
#include "Task.h"
#include "Message.h"
#include "Group.h"
#include "Instructor.h"
#include "Admin.h"
#include "Module.h"
#include "Student.h"
#include "Assesment.h"
// Include your class definitions here

void displayMainMenu()
{
    cout << BLUE;

    cout << "Welcome to the Project Management System" << endl;
    cout << "1. Student Menu" << endl;
    cout << "2. Instructor Menu" << endl;
    cout << "3. Admin Menu" << endl;
    cout << "4. Group Menu" << endl;
    cout << "5. Exit" << endl;
    cout << "Enter your choice: ";
}

void displayStudentMenu()
{
    cout << RED;
    cout << "Student Menu" << endl;
    cout << "1. Enroll in Course" << endl;
    cout << "2. Add an assignment " << endl;
    cout << "3. View Assignments" << endl;
    cout << "4. Submit Assignment" << endl;
    cout << "5. View Assignment marks: " << endl;
    cout << "6. Add a notification " << endl;
    cout << "7. Send Notification " << endl;
    cout << "8. View Notifications" << endl;
    cout << "9. View Certifications" << endl;
    cout << "10. Check Progress" << endl;
    cout << "11. Join Group" << endl;
    cout << "12. Leave Group" << endl;
    cout << "13. Display Groups" << endl;
    cout << "14. Display student information " << endl;
    cout << "15. Access individual student members using []: " << endl;
    cout << "16. Access individual student members using (): " << endl;
    cout << "17. Union of both student's courses: " << endl;
    cout << "18. Intersection of both student's courses: " << endl;
    cout << "19. Back to Main Menu" << endl;
    cout << "Enter your choice: ";
}

void displayInstructorMenu()
{
    cout << GREEN;
    cout << "Instructor Menu" << endl;
    cout << "1. Add Course" << endl;
    cout << "2. Add Students to Course" << endl;
    cout << "3. Create Assignments" << endl;
    cout << "4. Grade Submissions" << endl;
    cout << "5. Monitor Student Progress" << endl;
    cout << "6. Issue Certificate" << endl;
    cout << "7. Add Notification" << endl;
    cout << "8. Send Notification" << endl;
    cout << "9. View Notifications" << endl;
    cout << "10. Back to Main Menu" << endl;
    cout << "Enter your choice: ";
}

void displayAdminMenu()
{
    cout << YELLOW;
    cout << "Admin Menu" << endl;
    cout << "1. Add Course" << endl;
    cout << "2. Remove Course" << endl;
    cout << "3. Assign Instructor" << endl;
    cout << "4. Instructor information" << endl;
    cout << "5. Generate Report" << endl;
    cout << "6. Add certificate" << endl;
    cout << "7. Remove certificate" << endl;
    cout << "8. Manage Certificates" << endl;
    cout << "9. Send Notifications" << endl;
    cout << "10. Back to Main Menu" << endl;
    cout << "Enter your choice: ";
}

void displayGroupMenu()
{
    cout << ORANGE;
    cout << "Group Menu" << endl;
    cout << "1. Create Group" << endl;
    cout << "2. Add Member to Group" << endl;
    cout << "3. Remove Member from Group" << endl;
    cout << "4. Display Groups" << endl;
    cout << "5. Handle Peer Discussions" << endl;
    cout << "6. Facilitate Student Collaboration" << endl;
    cout << "7. Back to Main Menu" << endl;
    cout << "Enter your choice: ";
}

int main()
{

    // Create some initial objects for demonstration
    Student student1("AbdulMoeed", 1, "ABmoeed@example.com", 1001, "2023-01-01", 1, 4);
    Instructor instructor1;
    Admin admin1("Sammad", 3, "SI@example.com", 1003, "Administration", "Full Access");
    Course course1("Introduction to Programming", 101, "Basic programming concepts");
    Course course2("Data Structures", 102, "Advanced data structures and algorithms");
    Assignment assignment1(1, 100, "Write a program to sort an array", "2023-12-01", "completed", 20);
    Notification notification1("Welcome to the course!", 1, "24/5/2002");
    Certificate certificate1(324, "15/4/2016", "Speed Programming Winner", "Sammad");

    int instructorChoice, adminChoice, groupChoice;
    string groupName, memberName, courseTitle, description, sender, content, taskDesc, collaborationTask, discussionTopic;
    int courseCode;

    cout << "----------Welcome to course era---------- " << endl;

    int choice, studentChoice;
    bool stdFlag = true;
    bool exitProgram = false;
    int numStds, groupID, index;
    Student student, student2, unionResult, intersectionResult;

    Course course;
    Assignment stdAssignment;
    Notification stdNotification;
    string decision;

    //-----------------------------------------------
    // -----To achieve run time polimorphism---------
    //-----------------------------------------------
    Person *p1;
    p1 = &student;
    Person *p2 = &instructor1;

    while (!exitProgram)
    {
        displayMainMenu();
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            bool exitStudentMenu = false;
            if (stdFlag == true)
            {
                cout << "Enter the details of the student: " << endl;
                cin >> student;
            }

            while (!exitStudentMenu)
            {
                displayStudentMenu();
                cin >> studentChoice;

                switch (studentChoice)
                {
                case 1:
                {
                    cout << "Enter the details of the course: " << endl;
                    cin >> course;
                    student.enrollInCourse(course);
                    student.writeToBinaryFile("student_data.bin");
                    student.readFromBinaryFile("student_data.bin");
                    break;
                }

                case 2:
                {
                    // Add an assignment
                    cout << "Enter the details of the assignment: " << endl;
                    cin >> stdAssignment;

                    if (student.addAssignment(stdAssignment))
                    {
                        cout << "Assignment successfully added " << endl;
                    }
                    break;
                }

                case 3:
                {
                    // View Assignments
                    student.viewAssignments();
                    break;
                }

                case 4:
                {
                    // Submit Assignment
                    student.submitAssignment(stdAssignment);
                    break;
                }

                case 5:
                {

                    cout << "Absolutes: " << student.getAssignmentMarks(stdAssignment) << endl;
                    break;
                }

                case 6:
                {
                    // Add a notification
                    cout << "Enter for notification: " << endl;
                    cin >> stdNotification;

                    if (student.addNotification(stdNotification))
                    {
                        cout << "Notification added successfully " << endl;
                    }
                    break;
                }

                case 7:
                {
                    // Send Notification
                    cout << "Enter for notification: " << endl;
                    cin >> stdNotification;
                    student.sendNotification(stdNotification);
                    break;
                }

                case 8:
                {
                    student.viewNotifications();
                    break;
                }

                case 9:
                {
                    student.viewCertifications();
                    break;
                }

                case 10:
                {
                    student.checkProgress();
                    break;
                }

                case 11:
                {
                    // Join Group
                    cout << BLUE;
                    cout << "Enter Group ID to join: ";
                    cin >> groupID;
                    student.joinGroup(groupID);
                    break;
                }

                case 12:
                {
                    // Leave Group
                    cout << MAGENTA;
                    cout << "Enter Group ID to leave: ";
                    cin >> groupID;
                    student.leaveGroup(groupID);
                    break;
                }

                case 13:
                {
                    // Display Groups
                    student.displayGroups();
                    break;
                }

                case 14:
                {
                    // display student information
                    // student.displayInfo();
                    cout << "Student's Information: " << endl;
                    cout << student;
                    break;
                }

                case 15:
                {
                    cout << "0. Student ID " << endl;
                    cout << "1. Enrollment date " << endl;
                    cout << "2. Course completed count " << endl;
                    cout << "3. Enrolled courses count " << endl;
                    cout << "4. Number of notifications: " << endl;
                    cout << "5. Number of assignmets due" << endl;
                    cout << "6. Number of certificated received " << endl;
                    cout << "7. Number of groups " << endl;
                    cout << "Enter your choice: ";
                    cin >> index;

                    while (index < 0 || index > 7)
                    {
                        cout << "Invalid choics!!!\nEnter again: ";
                        cin >> index;
                    }

                    cout << "At index " << index << " we have " << student[index] << endl;
                    break;
                }

                case 16:
                {

                    cout << "0. studentID " << endl;
                    cout << "1. enrollmentDate " << endl;
                    cout << "2. courseCount" << endl;
                    cout << "3. enrolledCoursesCount" << endl;
                    cout << "4. notificationCount " << endl;
                    cout << "5. assignmentCount" << endl;
                    cout << "6. certificateCount " << endl;
                    cout << "7. groupCount " << endl;
                    cout << "Enter your choice(string): ";
                    cin >> decision;

                    cout << decision << ": " << student(decision) << endl;
                    break;
                }

                case 17:
                {
                    cout << "Enter the details for the student 2 " << endl;
                    cin >> student2;

                    // unionResult = student | student2;
                    student | student2;
                    // unionResult.displayEnrolledCourses();
                    break;
                }

                case 18:
                {
                    cout << "Enter the details for the student 2 " << endl;
                    cin >> student2;
                    // intersectionResult = student & student2;
                    student & student2;
                    // intersectionResult.displayEnrolledCourses();

                    break;
                }

                case 19:
                {
                    // Back to main menu
                    exitStudentMenu = true;
                    break;
                }

                default:
                {
                    cout << RED;
                    cout << "Invalid choice. Please try again." << endl;
                    break;
                }
                }
            }
            break;
        }
        case 2:
        {
            bool exitInstructorMenu = false;
            while (!exitInstructorMenu)
            {
                displayInstructorMenu();
                cin >> instructorChoice;
                switch (instructorChoice)
                {
                case 1:
                {
                    // Add Course
                    instructor1.addCourse(&course1);
                    break;
                }
                case 2:
                {
                    // Add Students to Course
                    instructor1.addStudentsToCourse(&student1, 0);
                    break;
                }
                case 3:
                {
                    // Create Assignments
                    instructor1.createAssignments(&course1, &assignment1);
                    break;
                }
                case 4:
                {
                    // Grade Submissions
                    instructor1.gradeSubmissions(student1, assignment1, "A");
                    break;
                }
                case 5:
                {
                    // Monitor Student Progress
                    instructor1.monitorStudentProgress(student1);
                    break;
                }
                case 6:
                {
                    // Issue Certificate
                    instructor1.issueCertificate(student1, course1);
                    break;
                }
                case 7:
                {
                    // Send Notification
                    instructor1.addNotification(notification1);
                    break;
                }
                case 8:
                    // send notification
                    instructor1.sendNotification(notification1);
                    break;
                case 9:
                {
                    // View Notifications
                    instructor1.viewNotifications();
                    break;
                }
                case 10:
                {
                    // Back to Main Menu
                    exitInstructorMenu = true;
                    break;
                }
                default:
                {
                    cout << BLUE;

                    cout << "Invalid choice. Please try again." << endl;
                    break;
                }
                }
            }
            break;
        }
        case 3:
        {
            bool exitAdminMenu = false;
            while (!exitAdminMenu)
            {
                displayAdminMenu();
                cin >> adminChoice;
                switch (adminChoice)
                {
                case 1:
                {
                    cout << GREEN;
                    cout << "Enter Course Title: ";
                    cin.ignore();
                    getline(cin, courseTitle);
                    cout << "Enter Course Code: ";
                    cin >> courseCode;
                    cout << "Enter Description: ";
                    cin.ignore();
                    getline(cin, description);
                    cout << admin1.addCourse(courseTitle, courseCode, description, 4) << endl;
                    break;
                }
                case 2:
                {
                    // Remove Course
                    cout << YELLOW;
                    cout << "Enter Course Code to remove: ";
                    cin >> courseCode;
                    cout << admin1.removeCourse(courseCode) << endl;
                    break;
                }
                case 3:
                {
                    // Assign Instructor
                    string name, department, email;
                    int id;
                    cout << "Enter instructor Name :";
                    cin.ignore();
                    getline(cin, name);
                    instructor1.setName(name);
                    cout << "Enter instructor department :";
                    getline(cin, department);
                    instructor1.setDepartment(department);
                    cout << "Enter instructor id :";
                    cin >> id;
                    instructor1.setID(id);
                    cout << "Enter Course Code to assign instructor: ";
                    cin.ignore();
                    cin >> courseCode;
                    cout << admin1.assignInstructor(courseCode, &instructor1) << endl;
                    break;
                }
                case 4:
                {
                    p2->displayInfo();
                    break;
                }
                case 5:
                {
                    // Generate Report
                    admin1.generateReport();
                    break;
                }
                case 6:
                    // Add certificate
                    admin1.addCertificate(&certificate1);
                    break;
                case 7:
                    // Remove certificate
                    int id;
                    cout << "Enter certificate id to remove it: ";
                    cin >> id;
                    admin1.removeCertificate(id);
                    break;
                case 8:
                {
                    // Manage Certificates
                    admin1.manageCertificates();
                    break;
                }
                case 9:
                {
                    // Send Notifications
                    admin1.sendNotification(notification1);
                    break;
                }
                case 10:
                {
                    // Back to Main Menu
                    exitAdminMenu = true;
                    break;
                }
                default:
                {
                    cout << BLUE;
                    cout << "Invalid choice. Please try again." << endl;
                    break;
                }
                }
            }
            break;
        }
        case 4:
        {
            bool exitGroupMenu = false;
            while (!exitGroupMenu)
            {
                displayGroupMenu();
                cin >> groupChoice;
                switch (groupChoice)
                {
                case 1:
                {
                    // Create Group
                    cout << "Enter Group ID: ";
                    cin >> groupID;
                    cout << "Enter Group Name: ";
                    cin.ignore();
                    getline(cin, groupName);
                    Group::createGroup(groupID, groupName);
                    break;
                }
                case 2:
                {
                    // Add Member to Group
                    cout << "Enter Group ID: ";
                    cin >> groupID;
                    cout << "Enter Member Name: ";
                    cin.ignore();
                    getline(cin, memberName);
                    Group::addMemberToGroup(groupID, memberName);
                    break;
                }
                case 3:
                {
                    // Remove Member from Group
                    cout << BLUE;
                    cout << "Enter Group ID: ";
                    cin >> groupID;
                    cout << "Enter Member Name: ";
                    cin.ignore();
                    getline(cin, memberName);
                    Group::removeMemberFromGroup(groupID, memberName);
                    break;
                }
                case 4:
                {
                    // Display Groups
                    Group::displayGroups();
                    break;
                }
                case 5:
                {
                    // Handle Peer Discussions
                    Group::handlePeerDiscussions();
                    break;
                }
                case 6:
                {
                    // Facilitate Student Collaboration
                    Group::facilitateStudentCollaboration();
                    break;
                }
                case 7:
                {
                    // Back to Main Menu
                    exitGroupMenu = true;
                    break;
                }
                default:
                {
                    cout << BLUE;
                    cout << "Invalid choice. Please try again." << endl;
                    break;
                }
                }
            }
            break;
        }
        case 5:
        {
            // Exit the program
            delete p1;
            delete p2;
            break;
        }
        default:
        {
            cout << BLUE;
            cout << "Invalid choice. Please try again." << endl;
            break;
        }
        }
    }

    return 0;
}