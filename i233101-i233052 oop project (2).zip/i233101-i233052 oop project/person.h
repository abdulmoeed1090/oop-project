
#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <string>
#include "Notification.h"

constexpr const char *RED = "\033[31m";
constexpr const char *BLUE = "\033[34m";
constexpr const char *GREEN = "\033[32m";
constexpr const char *reset = "\033[0m";
constexpr const char *YELLOW = "\033[33m";
constexpr const char *MAGENTA = "\033[35m";
constexpr const char *ORANGE = "\033[38;5;208m";
using namespace std;

// Abstract base class
class Person
{
protected:
    string name;
    int ID;
    string email;

public:
    // constructors
    Person()
    {
        name = "";
        ID = 0;
        email = "";
    }
    Person(string name, int ID, string email)
    {
        this->name = name;
        this->ID = ID;
        this->email = email;
    }
    virtual ~Person() {};
    virtual void displayInfo() = 0;
    virtual string getRole() = 0;
    virtual bool sendNotification(const Notification &notification) = 0;
};

#endif